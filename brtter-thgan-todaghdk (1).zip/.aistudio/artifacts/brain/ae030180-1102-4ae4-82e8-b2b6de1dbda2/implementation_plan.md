# Final Fix Loop (Fix Pack V2) Implementation Plan

Delivers the six targeted fixes requested in `Final_Fix_Loop_ff395833.md` (FIX-18 through FIX-23), continuing from the existing codebase without restyling or unnecessary additions, while strictly obeying the Polaris/Raymond design system and user-confirmed preferences.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions have been aligned based on your responses and the specification defaults:
> - **Cutting Slip Quantity**: One slip per item line, showing the quantity label (e.g. `Qty 2`) when quantity is greater than 1.
> - **Set Item Buttons**: A single "Cutting Slip" button for set items (e.g. Meskit) that renders both Shirt and Pant slip cards together.
> - **Delivery Screen Organization**: Retain the existing tabs (Officer Orders / Airman Orders) displaying pending deliveries.
> - **Slip Type Defaults**: Items containing "Pant" default to **Pant**; items containing "Shirt" or "Sleeve" default to **Shirt**; all other items (Meskit, Uniforms) default to **Shirt + Pant**. Owners can adjust this in Settings.
> - **Airman Orders Clean-up**: Trade and Office are completely removed from forms, cards, order details, cutting slip headers, search queries, and settings. Old data remains preserved in storage without ever rendering.
> - **Delivery Flow**: Delivery action and status dropdown selection for "Delivered" route through **Delivery Details → Deliver This Order → Confirm Delivery** page before completing.

---

## 1. Overview & Core Concept

- **FIX-18 (Item Rows: Edit First, Save on Add Item)**:
  - New Order forms open with row #1 as an active editing row (prefilled with first item, quantity 1), **not yet part of the order total or count**.
  - Clicking "Add Item" commits the row into a saved items list above it (compact line with pencil and trash icons), updates the totals, and spawns a fresh default editing row below.
  - Airman form requires an IV-Number before saving an item.
  - In existing orders/drafts, existing items load as saved lines with a fresh editing row below.
- **FIX-19 (Airman Orders: Remove Trade and Office)**:
  - Completely strip Trade and Office dropdowns, table cells, card labels, details cards, cutting slip headers, settings lists, and search filters.
  - Keep BD Number, Name, Phone, Ribbon, Running Year, and item IV-Numbers untouched.
- **FIX-20 (Cutting Slip Per Item & Single Print Sheet)**:
  - Each item line has its own slip type (`Shirt`, `Pant`, or `Shirt + Pant`). Set items generate two separate cards (Shirt slip and Pant slip).
  - Compact format: bold header (`#546 ~ S/L ERFAN ~ 10133`), ribbon/branch top right, item name (+ IV-Number for Airman), clean measurement values joined with `~`, notes, and part name + delivery date (or order date for Airman) at the bottom.
  - Per-item "Cutting Slip" button on each order item line; global "Print Slip" button prints all slips on a 2-column print sheet with zero split cards across pages in a single browser print dialog.
- **FIX-21 (Delivery: Details Page then Confirm Delivery)**:
  - Tapping "Deliver" or selecting "Delivered" navigates to the order's Delivery Details view with a "Deliver This Order" button.
  - Clicking "Deliver This Order" navigates to the dedicated **Confirm Delivery** page containing: Delivered Date (default today), Total Amount, editable Discount, Advance, editable Cash Receive, live calculated Due, Receiver Name, and Receiver Phone.
  - Confirming records the delivery date, receiver info, discount, and optional cash receipt payment record. Cancel leaves order in its previous state.
  - Airman orders show only Delivered Date, Receiver Name, Receiver Phone, Cancel, and Confirm Delivery.
- **FIX-22 (Reports Download as PDF)**:
  - Replace CSV and print buttons on Dashboard, Staff Summary, Staff Management worker month page, and Payslip with a single **Download PDF** button.
  - Generates and downloads real `.pdf` files instantly using `jspdf` and `jspdf-autotable`.
  - Bundles the lightweight `Noto Sans Bengali` font offline so Bengali staff names and the `৳` currency sign render cleanly without boxes or internet access.
- **FIX-23 (Due After Delivery Card)**:
  - Replaces the "Pending Cutting Slip" card on the Officer Orders screen with the red **Due After Delivery** card.
  - Displays total Due taka and count of Delivered orders where Due > 0. Clicking the card toggles the list filter with a clearable filter chip.

---

## 2. User Experience & Visual Design

- **Visual Consistency**: Adheres to the established Shopify Polaris / Raymond monochrome design system (`#1A1A1A` dark accents, clean `#E3E3E3` borders, `#FAFAFA` surfaces, native tabular numbers).
- **Anti-Slop Discipline**: Zero unboxed pill badges for static metadata, no decorative pulsing dots or pseudo-code commentary.
- **Form Interactivity**:
  - Compact saved item rows with smooth hover states, pencil edit button that switches the item row into editing mode with an "Update Item" button.
  - Live validation on Cash Receive and Discount preventing negative numbers or over-payments.
- **Print & PDF Fidelity**:
  - Two-column CSS grid with `break-inside: avoid` and `@page` rules for cutting slips.
  - Formatted PDF headers with shop name, report date, tabular data with repeating headers on page breaks, and page footers ("Page X of Y").

---

## 3. Key Product Decisions & Trade-Offs

- **Client-Side PDF Generation**: Using `jspdf` + `jspdf-autotable` with a local bundled base64/arrayBuffer Bengali TrueType font (`NotoSansBengali-Regular.ttf`).
  - *Why*: Instant download without server hops, zero external network dependency, hermetic in offline/PWA mode, and produces crisp vector PDFs with repeatable headers and page counts.
- **In-Place Navigation for Delivery Flow**:
  - *Why*: The specification calls for a full **page** (not a modal) for Confirm Delivery (`onNavigate('confirm-delivery', { orderNumber, category })`). This provides ample breathing room on mobile and desktop for financial calculations and receiver input.
- **Editing Row Persistence in Drafts**:
  - If an editing row was touched (changed from default), it is preserved in drafts and validated on save. Untouched default rows are cleanly discarded.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        App State (AppContext)                          │
│                                                                        │
│ • officerOrders / airmanOrders (receiverName, receiverPhone, slipType) │
│ • settings (items with slipType, airmanItems with slipType)            │
│ • workers / workerRows / workerPayments                                │
└──────────────────┬─────────────────────────────────┬───────────────────┘
                   │                                 │
                   ▼                                 ▼
      ┌───────────────────────────┐     ┌────────────────────────────┐
      │     Order Management      │     │       Delivery Flow        │
      ├───────────────────────────┤     ├────────────────────────────┤
      │ • OfficerOrderForm        │     │ • DeliveryScreen           │
      │ • AirmanOrderForm         │     │ • OrderDetailsScreen       │
      │   (FIX-18: Edit & Add)    │     │   ("Deliver This Order")   │
      │   (FIX-19: No Trade/Office│     │ • ConfirmDeliveryScreen    │
      │ • OfficerOrdersScreen     │     │   (FIX-21: Live calc &     │
      │   (FIX-23: Due After Del) │     │    receiver record)        │
      └─────────────┬─────────────┘     └────────────────────────────┘
                    │
                    ▼
      ┌───────────────────────────┐     ┌────────────────────────────┐
      │    Cutting Slip Engine    │     │    PDF Reporting Engine    │
      ├───────────────────────────┤     ├────────────────────────────┤
      │ • PrintPreviewScreen      │     │ • src/utils/pdfGenerator.ts│
      │   - Per-item slip filter  │     │   (jspdf + autotable +     │
      │   - Shirt/Pant separation │     │    NotoSansBengali font)   │
      │   - 2-col printable sheet │     │ • Dashboard PDF            │
      │   (FIX-20)                │     │ • Staff Summary PDF        │
      │                           │     │ • Worker Month PDF         │
      │                           │     │ • Payslip PDF (FIX-22)     │
      └───────────────────────────┘     └────────────────────────────┘
```

### Component & File Mapping

1. `src/types/index.ts`:
   - Add `SlipType = 'Shirt' | 'Pant' | 'Shirt + Pant'`
   - Update `ItemDefinition` & `AirmanItemDefinition` with `slipType?: SlipType`
   - Update `OfficerOrder` & `AirmanOrder` with `receiverName?: string; receiverPhone?: string;`
2. `src/utils/starterData.ts`:
   - Add default `slipType` logic to starter items (`Pant` for pants, `Shirt` for shirts, `Shirt + Pant` for others).
3. `src/components/OfficerOrderForm.tsx`:
   - Implement FIX-18: active editing row + saved items list + Add Item commit + touched row handling.
4. `src/components/AirmanOrderForm.tsx`:
   - Implement FIX-18: active editing row with mandatory IV-Number validation.
   - Implement FIX-19: remove Trade and Office dropdowns.
5. `src/components/AirmanOrdersScreen.tsx` & `src/utils/logic.ts`:
   - Remove Trade and Office from cards, table columns, details, and search logic.
6. `src/components/SettingsScreen.tsx`:
   - Add `Slip type` selector on item edit rows (Shirt, Pant, Shirt + Pant).
   - Remove Trade and Office lists from Settings.
7. `src/components/PrintPreviewScreen.tsx`:
   - Overhaul cutting slip rendering for FIX-20: per-item filter (support single item or all items), separate Shirt and Pant slips, compact layout, delivery/order date, joined measurement string with `F-` and `B-` prefixes, no prices.
8. `src/components/OrderDetailsScreen.tsx`:
   - Add per-item "Cutting Slip" buttons in the ordered items table.
   - Add "Deliver This Order" button at bottom for undelivered orders.
   - Intercept "Delivered" status change to navigate to Confirm Delivery.
   - Display receiver details on delivered orders.
   - Remove Trade and Office displays for Airman orders.
9. `src/components/DeliveryScreen.tsx` & `src/components/ConfirmDeliveryScreen.tsx`:
   - Row click or "Deliver" navigates to Order Details (Delivery Details) with "Deliver This Order" button.
   - Dedicated `ConfirmDeliveryScreen.tsx` for FIX-21 with live Due calculation, discount editing, and cash receipt entry.
10. `src/components/OfficerOrdersScreen.tsx`:
    - Implement FIX-23: replace Pending Cutting Slip card with red "Due After Delivery" card (sum of due on delivered orders) and active filter chip.
11. `src/utils/pdfGenerator.ts`:
    - Implement FIX-22 client-side PDF downloads for Dashboard, Staff Summary, Worker Month, and Payslip with embedded Bengali glyphs and `৳` symbol.
    - Remove CSV buttons in `DashboardScreen.tsx`, `StaffSummaryScreen.tsx`, and `WorkerPage.tsx`.

---

## 5. Verification Plan

- **FIX-18**: Verify New Order opens with row #1 unstaged; modifying item/qty and clicking "Add Item" commits row and clears editing row. Verify Airman requires IV-Number.
- **FIX-19**: Verify full removal of Trade and Office across Airman form, cards, details, and Settings.
- **FIX-20**: Verify per-item Cutting Slip buttons on Order Details (single item and Meskit set item creating two slips), and global Print Slip button formatting two columns.
- **FIX-21**: Verify Delivery → Deliver → Details → Deliver This Order → Confirm Delivery flow. Test Discount adjustments and Cash Receive creating a payment record. Test Cancel leaves order intact.
- **FIX-22**: Verify clicking Download PDF on Dashboard, Staff Summary, and Worker Month downloads real `.pdf` files immediately with proper Bengali names and `৳` signs.
- **FIX-23**: Verify Due After Delivery card displays accurate sum and count, filters list on click, and clears filter on chip click.
- Run `compile_applet` and `lint_applet` to verify clean compilation.
