import React, { useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder, OrderStatus } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import { ManageItemsModal } from './ManageItemsModal.tsx';
import { formatDate, isOrderUpcoming } from '../utils/logic.ts';
import {
  EmptyOrdersGlassIllustration,
  DeleteWarningGlassIllustration,
} from './Illustrations.tsx';
import {
  Plus,
  Search,
  ArrowUpDown,
  Printer,
  Edit2,
  Trash2,
  CreditCard,
  Truck,
  Plane,
  X,
  AlertCircle,
  Scissors,
  Calendar,
  AlertTriangle,
  LayoutGrid,
  List,
  ChevronLeft,
  ChevronRight,
  Tag,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

function getDeliveryDiffDays(deliveryDateStr: string | undefined, today: string) {
  if (!deliveryDateStr) return null;
  const dDate = new Date(deliveryDateStr).getTime();
  const tDate = new Date(today).getTime();
  const diffDays = Math.round((dDate - tDate) / (1000 * 3600 * 24));
  return diffDays;
}

interface OfficerOrdersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const OfficerOrdersScreen: React.FC<OfficerOrdersScreenProps> = ({ onNavigate }) => {
  const { state, loading, updateOfficerOrderStatus, deleteOfficerOrder, recordOfficerPayment } = useApp();

  const [activeTab, setActiveTab] = useState<'All' | OrderStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [activeCardFilter, setActiveCardFilter] = useState<'upcoming' | 'dueAfterDelivery' | null>(null);

  // Pay Dialog State
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);

  // Manage Prices Modal state
  const [managePricesOpen, setManagePricesOpen] = useState(false);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Delete Dialog State (Two-step delete)
  const [deleteTargetOrder, setDeleteTargetOrder] = useState<OfficerOrder | null>(null);
  const [deleteStep, setDeleteStep] = useState<1 | 2>(1);

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Calculate Summary Cards
  const upcomingOrders = useMemo(() => {
    return state.officerOrders.filter((o) =>
      isOrderUpcoming(o.deliveryDate, o.status === 'Delivered', todayStr, upcomingDays)
    );
  }, [state.officerOrders, todayStr, upcomingDays]);

  const dueAfterDeliveryOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Delivered' && o.due > 0);
  }, [state.officerOrders]);

  const totalDueAfterDelivery = useMemo(() => {
    return dueAfterDeliveryOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [dueAfterDeliveryOrders]);

  // Tab counts
  const tabCounts = useMemo(() => {
    return {
      All: state.officerOrders.length,
      Pending: state.officerOrders.filter((o) => o.status === 'Pending').length,
      'Cutting Slip – Done': state.officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      Delivered: state.officerOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [state.officerOrders]);

  // Filtered and Sorted Orders
  const filteredOrders = useMemo(() => {
    return state.officerOrders
      .filter((order) => {
        // Tab filter
        if (activeTab !== 'All' && order.status !== activeTab) return false;

        // Card filter
        if (activeCardFilter === 'upcoming') {
          if (!isOrderUpcoming(order.deliveryDate, order.status === 'Delivered', todayStr, upcomingDays)) {
            return false;
          }
        } else if (activeCardFilter === 'dueAfterDelivery') {
          if (order.status !== 'Delivered' || order.due <= 0) return false;
        }

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesName = order.customerName.toLowerCase().includes(q);
          const matchesPhone = (order.customerPhone || '').toLowerCase().includes(q);
          const matchesBd = order.customerBdNumber.toLowerCase().includes(q);
          const matchesOrderNum = String(order.orderNumber).includes(q) || `#${order.orderNumber}`.includes(q);
          if (!matchesName && !matchesPhone && !matchesBd && !matchesOrderNum) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortOrder === 'newest') {
          return b.orderNumber - a.orderNumber;
        } else {
          return a.orderNumber - b.orderNumber;
        }
      });
  }, [state.officerOrders, activeTab, activeCardFilter, searchQuery, sortOrder, todayStr, upcomingDays]);

  const handleDeleteClick = (e: React.MouseEvent, order: OfficerOrder) => {
    e.stopPropagation();
    setDeleteTargetOrder(order);
    setDeleteStep(1);
  };

  const handleConfirmDeleteStep1 = () => {
    setDeleteStep(2);
  };

  const handleConfirmDeleteStep2 = () => {
    if (deleteTargetOrder) {
      deleteOfficerOrder(deleteTargetOrder.orderNumber);
      setDeleteTargetOrder(null);
      setDeleteStep(1);
    }
  };

  const handlePayClick = (e: React.MouseEvent, order: OfficerOrder) => {
    e.stopPropagation();
    setPayTargetOrder(order);
  };

  const handleConfirmPay = () => {
    if (payTargetOrder) {
      recordOfficerPayment(payTargetOrder.orderNumber, payTargetOrder.due);
      setPayTargetOrder(null);
    }
  };

  const scrollTable = (direction: 'left' | 'right') => {
    if (tableContainerRef.current) {
      const offset = direction === 'left' ? -320 : 320;
      tableContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <PolarisPage
      title="Officer Orders"
      subtitle="Manage uniform orders, cutting slips, deliveries, and balances"
      secondaryActions={[
        {
          label: 'Manage Prices',
          onClick: () => setManagePricesOpen(true),
          icon: <Tag className="w-3.5 h-3.5" />,
        },
        {
          label: 'Delivery',
          onClick: () => onNavigate('delivery'),
          icon: <Truck className="w-3.5 h-3.5" />,
        },
        {
          label: 'Airman Orders',
          onClick: () => onNavigate('airman-orders'),
          icon: <Plane className="w-3.5 h-3.5" />,
        },
      ]}
      primaryAction={{
        label: 'New Order',
        onClick: () => onNavigate('new-officer-order'),
        icon: <Plus className="w-3.5 h-3.5" />,
      }}
      fullWidth={true}
    >
      {/* High-Contrast Polaris Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Upcoming to Deliver Card */}
        <div
          onClick={() =>
            setActiveCardFilter((prev) => (prev === 'upcoming' ? null : 'upcoming'))
          }
          className={`p-4 rounded-[12px] border transition-all cursor-pointer shadow-[0_1px_0_rgba(26,26,26,0.07)] flex flex-col justify-between ${
            activeCardFilter === 'upcoming'
              ? 'border-[#303030] ring-1 ring-[#303030] bg-[#FAFAFA]'
              : 'bg-white border-[#E3E3E3] hover:border-[#8A8A8A]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-[550] text-[#303030]">Upcoming to Deliver</span>
            <span className="text-[12px] px-2 py-0.5 rounded-[8px] font-[550] bg-[#FFEA8A] text-[#5E4200]">
              Next {upcomingDays} days
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-[20px] leading-[28px] font-[650] text-[#1A1A1A] tabular-nums">
              {upcomingOrders.length} <span className="text-[13px] font-[450] text-[#616161]">orders due</span>
            </div>
            <span className="text-[13px] text-[#005BD3] hover:underline font-[450]">
              {activeCardFilter === 'upcoming' ? '✕ Clear filter' : 'Filter upcoming →'}
            </span>
          </div>
        </div>

        {/* Due After Delivery Card (replaces Pending Cutting Slips per FIX-23) */}
        <div
          onClick={() =>
            setActiveCardFilter((prev) => (prev === 'dueAfterDelivery' ? null : 'dueAfterDelivery'))
          }
          className={`p-4 rounded-[12px] border transition-all cursor-pointer shadow-[0_1px_0_rgba(26,26,26,0.07)] flex flex-col justify-between ${
            activeCardFilter === 'dueAfterDelivery'
              ? 'border-[#8E0B21] ring-1 ring-[#8E0B21] bg-[#FFF8F8]'
              : 'bg-white border-[#E3E3E3] hover:border-[#8E0B21]/50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-[550] text-[#303030]">Due After Delivery</span>
            <span className="text-[12px] px-2 py-0.5 rounded-[8px] font-[550] bg-[#FEE9E8] text-[#8E0B21]">
              {dueAfterDeliveryOrders.length} orders
            </span>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div className="text-[20px] leading-[28px] font-[650] text-[#8E0B21] tabular-nums">
              ৳{totalDueAfterDelivery.toLocaleString()}
            </div>
            <span className="text-[13px] text-[#8E0B21] hover:underline font-[450]">
              {activeCardFilter === 'dueAfterDelivery' ? '✕ Clear filter' : 'Filter due →'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <PolarisCard flush={true}>
        {/* Saved Views Tabs & Search/Sort Bar */}
        <PolarisTabs
          tabs={[
            { id: 'All', label: 'All', count: tabCounts.All },
            { id: 'Pending', label: 'Pending', count: tabCounts.Pending },
            { id: 'Cutting Slip – Done', label: 'Cutting Slip – Done', count: tabCounts['Cutting Slip – Done'] },
            { id: 'Delivered', label: 'Delivered', count: tabCounts.Delivered },
          ]}
          selectedTab={activeTab}
          onSelectTab={(tabId) => setActiveTab(tabId as any)}
          tools={
            <div className="flex items-center space-x-2">
              {/* Search Box */}
              <div className="relative w-48 sm:w-60">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
                <input
                  type="text"
                  placeholder="Filter name, phone, BD, #"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-7 pl-8 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030] text-[#303030]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-[#8A8A8A] hover:text-[#303030]"
                    aria-label="Clear filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Sort Dropdown */}
              <div className="relative">
                <select
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
                  className="h-7 pl-2.5 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] focus:outline-none focus:border-[#303030] cursor-pointer"
                  aria-label="Sort order"
                >
                  <option value="newest">Newest first</option>
                  <option value="oldest">Oldest first</option>
                </select>
              </div>

              {/* Horizontal Scroll Assist Controls (Table Mode) */}
              {viewMode === 'table' && (
                <div className="flex items-center space-x-1 border border-[#E3E3E3] rounded-lg p-0.5 bg-white">
                  <button
                    type="button"
                    onClick={() => scrollTable('left')}
                    title="Slide table left"
                    className="p-1 hover:bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A] rounded transition-colors"
                    aria-label="Scroll table left"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] font-semibold text-[#8A8A8A] px-1 select-none">Slide</span>
                  <button
                    type="button"
                    onClick={() => scrollTable('right')}
                    title="Slide table right"
                    className="p-1 hover:bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A] rounded transition-colors"
                    aria-label="Scroll table right"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* View Mode Toggle: Grid vs Table */}
              <div className="flex items-center bg-[#EBEBEB] p-0.5 rounded-lg border border-[#E3E3E3]">
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  title="Card View (No side-scroll)"
                  className={`p-1 rounded-md transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-white text-[#1A1A1A] shadow-2xs font-semibold'
                      : 'text-[#616161] hover:text-[#1A1A1A]'
                  }`}
                  aria-label="Grid view"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('table')}
                  title="List Table View (Sticky columns)"
                  className={`p-1 rounded-md transition-colors ${
                    viewMode === 'table'
                      ? 'bg-white text-[#1A1A1A] shadow-2xs font-semibold'
                      : 'text-[#616161] hover:text-[#1A1A1A]'
                  }`}
                  aria-label="Table view"
                >
                  <List className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          }
        />

        {/* Active Card Filter Chip */}
        {activeCardFilter && (
          <div className="px-4 py-2 bg-[#F6F6F6] border-b border-[#E3E3E3] flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-[#616161]">Filter:</span>
              <button
                type="button"
                onClick={() => setActiveCardFilter(null)}
                className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md text-xs font-[600] bg-white border border-[#E3E3E3] text-[#8E0B21] hover:bg-rose-50 shadow-2xs cursor-pointer transition-colors"
              >
                <span>
                  {activeCardFilter === 'dueAfterDelivery'
                    ? 'Filter: Due After Delivery'
                    : 'Filter: Upcoming to Deliver'}
                </span>
                <X className="w-3.5 h-3.5 text-[#8E0B21]" />
              </button>
            </div>
            <button
              type="button"
              onClick={() => setActiveCardFilter(null)}
              className="text-xs text-[#616161] hover:text-[#1A1A1A] font-medium cursor-pointer"
            >
              Clear
            </button>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="p-8 space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-12 bg-[#F1F1F1] rounded-lg animate-pulse" />
            ))}
          </div>
        )}

        {/* Empty State with Apple Glass styling */}
        {!loading && filteredOrders.length === 0 && (
          <div className="py-16 px-4 text-center flex flex-col items-center justify-center">
            <EmptyOrdersGlassIllustration category="Officer" className="w-28 h-28 mb-4" />
            <h3 className="text-base font-bold text-neutral-900 tracking-tight">No Officer Orders Found</h3>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1.5 max-w-sm leading-relaxed">
              {searchQuery || activeCardFilter || activeTab !== 'All'
                ? 'No orders match your active search or filters. Reset filters to see all officer orders.'
                : 'No officer orders have been created yet. Start a new bespoke tailoring order.'}
            </p>
            {searchQuery || activeCardFilter || activeTab !== 'All' ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCardFilter(null);
                  setActiveTab('All');
                }}
                className="mt-5 min-h-[40px] px-5 rounded-xl bg-white hover:bg-neutral-50 text-neutral-800 text-sm font-semibold border border-neutral-300 shadow-xs cursor-pointer transition-all active:translate-y-px"
              >
                Reset Filters
              </button>
            ) : (
              <button
                onClick={() => onNavigate('new-officer-order')}
                className="mt-5 btn-primary text-sm shadow-[0_2px_8px_rgba(0,0,0,0.25)] cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Create First Officer Order</span>
              </button>
            )}
          </div>
        )}

        {/* Orders Content: Big Box Grid (Default) or Table View */}
        {!loading && filteredOrders.length > 0 && viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5 p-4 sm:p-5 bg-[#F9FAFB] border-t border-[#E3E3E3]">
            {filteredOrders.map((order) => {
              const hasDue = order.due > 0;
              const totalAmount = Number(order.totalAmount) || 0;
              const advance = Number(order.advance) || 0;
              const paidAmount = totalAmount - order.due;
              const paidPercent = totalAmount > 0 ? Math.min(100, Math.round((paidAmount / totalAmount) * 100)) : 100;
              const diffDays = getDeliveryDiffDays(order.deliveryDate, todayStr);
              const isOverdue = order.status !== 'Delivered' && diffDays !== null && diffDays < 0;

              return (
                <div
                  key={order.id}
                  onClick={() =>
                    onNavigate('order-details', {
                      orderNumber: order.orderNumber,
                      category: 'Officer',
                    })
                  }
                  className="bg-white rounded-2xl border border-[#E3E3E3] hover:border-[#1A1A1A] p-5 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                >
                  {/* Top Header */}
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-[#1A1A1A] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                          #{order.orderNumber}
                        </div>
                        <div>
                          <h4 className="font-bold text-[#1A1A1A] text-[15px] leading-snug group-hover:text-[#005BD3] transition-colors line-clamp-1">
                            {order.customerName}
                          </h4>
                          <div className="text-xs text-[#616161] flex items-center gap-1.5 mt-0.5">
                            <span>Officer</span>
                            <span>·</span>
                            <span className="font-mono font-medium">BD/{order.customerBdNumber}</span>
                            {order.branch && (
                              <span className="font-semibold text-[#005BD3] bg-[#EAF4FF] px-1.5 py-0.2 rounded text-[10px]">
                                {order.branch}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Status & Overdue Badges */}
                    <div className="flex flex-wrap items-center gap-2 mb-3.5" onClick={(e) => e.stopPropagation()}>
                      <StatusBadge
                        status={order.status}
                        interactive={true}
                        onChange={(newStatus) => updateOfficerOrderStatus(order.orderNumber, newStatus)}
                      />
                      {isOverdue && (
                        <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#FEE9E8] text-[#8E0B21] border border-[#FCD2D0]">
                          Overdue {Math.abs(diffDays!)} {Math.abs(diffDays!) === 1 ? 'day' : 'days'}
                        </span>
                      )}
                      {!isOverdue && diffDays !== null && diffDays >= 0 && diffDays <= upcomingDays && order.status !== 'Delivered' && (
                        <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#FEF3C7] text-[#92400E] border border-[#FDE68A]">
                          Due {diffDays === 0 ? 'Today' : `in ${diffDays}d`}
                        </span>
                      )}
                    </div>

                    {/* Dates Grid */}
                    <div className="grid grid-cols-2 gap-2 text-xs py-2.5 border-y border-[#F0F0F0] mb-3.5">
                      <div>
                        <span className="text-[#8A8A8A] text-[11px] block">Order date</span>
                        <span className="font-medium text-[#303030] font-mono">{order.orderDate}</span>
                      </div>
                      <div>
                        <span className="text-[#8A8A8A] text-[11px] block">Delivery date</span>
                        <span className={`font-semibold font-mono ${isOverdue ? 'text-[#8E0B21]' : 'text-[#303030]'}`}>
                          {order.deliveryDate || '—'}
                        </span>
                      </div>
                    </div>

                    {/* Items snippet */}
                    <div className="text-xs text-[#616161] mb-4 line-clamp-1">
                      <span className="text-[#8A8A8A]">Items: </span>
                      {order.items.map((i) => `${i.name} (${i.quantity})`).join(', ')}
                    </div>
                  </div>

                  {/* Financial Breakdown & Progress */}
                  <div>
                    <div className="grid grid-cols-3 gap-2 text-center py-2 bg-[#F8F9FA] rounded-xl mb-2.5">
                      <div>
                        <span className="text-[10px] text-[#8A8A8A] block uppercase tracking-wider">Total</span>
                        <span className="font-semibold text-xs text-[#1A1A1A] font-mono tabular-nums">৳{totalAmount.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-[#8A8A8A] block uppercase tracking-wider">Advance</span>
                        <span className="font-semibold text-xs text-[#1A1A1A] font-mono tabular-nums">৳{advance.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-[#8A8A8A] block uppercase tracking-wider">Due</span>
                        <span className={`font-bold text-xs font-mono tabular-nums ${hasDue ? 'text-[#DC2626]' : 'text-[#16A34A]'}`}>
                          ৳{order.due.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="w-full bg-[#E5E7EB] h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            paidPercent === 100 ? 'bg-[#16A34A]' : 'bg-[#1A1A1A]'
                          }`}
                          style={{ width: `${paidPercent}%` }}
                        />
                      </div>
                      <div className="flex justify-between items-center text-[10px] text-[#8A8A8A] mt-1 font-mono">
                        <span>৳{paidAmount.toLocaleString()} collected</span>
                        <span>{paidPercent}% paid</span>
                      </div>
                    </div>

                    {/* Action Row */}
                    <div className="flex items-center justify-between pt-2 border-t border-[#F0F0F0]" onClick={(e) => e.stopPropagation()}>
                      {hasDue ? (
                        <button
                          type="button"
                          onClick={(e) => handlePayClick(e, order)}
                          className="h-8 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-[#1A1A1A] shadow-xs"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          <span>Pay ৳{order.due.toLocaleString()}</span>
                        </button>
                      ) : (
                        <span className="inline-flex items-center text-xs font-semibold text-[#16A34A] py-1">
                          ✓ Paid in full
                        </span>
                      )}

                      <div className="flex items-center space-x-1">
                        <button
                          type="button"
                          onClick={() => onNavigate('print-slip', { orderNumber: order.orderNumber, category: 'Officer' })}
                          title="Cutting Slip"
                          className="p-1.5 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded-lg transition-colors"
                        >
                          <Scissors className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onNavigate('print-invoice', { orderNumber: order.orderNumber, category: 'Officer' })}
                          title="Invoice"
                          className="p-1.5 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded-lg transition-colors"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onNavigate('edit-officer-order', { orderNumber: order.orderNumber })}
                          title="Edit"
                          className="p-1.5 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleDeleteClick(e, order)}
                          title="Delete"
                          className="p-1.5 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FEE9E8] rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* 54px Polaris IndexTable */}
        {!loading && filteredOrders.length > 0 && viewMode === 'table' && (
          <div ref={tableContainerRef} className="overflow-x-auto relative scroll-smooth overscroll-x-contain">
            <table className="w-full border-collapse text-left min-w-[760px]">
              <thead>
                <tr className="h-9 border-b border-[#E3E3E3] bg-[#FAFAFA] text-[13px] font-[450] text-[#616161]">
                  <th className="px-3 w-20 text-left sticky left-0 z-20 bg-[#FAFAFA] border-r border-[#EBEBEB] shadow-[2px_0_4px_rgba(0,0,0,0.03)]">
                    Order
                  </th>
                  <th className="px-3 text-left">Customer</th>
                  <th className="px-3 text-left">Items</th>
                  <th className="px-3 text-left">Dates</th>
                  <th className="px-3 text-right">Total</th>
                  <th className="px-3 text-right">Due</th>
                  <th className="px-3 text-center w-36">Status</th>
                  <th className="px-3 text-right w-40 sticky right-0 z-20 bg-[#FAFAFA] border-l border-[#EBEBEB] shadow-[-2px_0_4px_rgba(0,0,0,0.03)]">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3E3E3] text-[13px]">
                {filteredOrders.map((order) => {
                  const hasDue = order.due > 0;
                  const canPay = order.status === 'Delivered' && hasDue;

                  return (
                    <tr
                      key={order.id}
                      onClick={() =>
                        onNavigate('order-details', {
                          orderNumber: order.orderNumber,
                          category: 'Officer',
                        })
                      }
                      className="h-[54px] hover:bg-[#F7F7F7] cursor-pointer transition-colors group"
                    >
                      {/* Order # (Sticky Left) */}
                      <td className="px-3 font-[650] text-[#1A1A1A] sticky left-0 z-10 bg-white group-hover:bg-[#F7F7F7] border-r border-[#EBEBEB] shadow-[2px_0_4px_rgba(0,0,0,0.03)]">
                        #{order.orderNumber}
                      </td>

                      {/* Customer Name & BD */}
                      <td className="px-3">
                        <div className="font-[550] text-[#1A1A1A] line-clamp-1">
                          {order.customerName}
                        </div>
                        <div className="text-[11px] text-[#616161] flex items-center space-x-1.5 mt-0.5">
                          <span>BD: {order.customerBdNumber}</span>
                          {order.customerPhone && <span>· {order.customerPhone}</span>}
                          {order.branch && (
                            <span className="font-semibold text-[#005BD3] bg-[#EAF4FF] px-1 py-0.2 rounded text-[10px]">
                              {order.branch}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Items */}
                      <td className="px-3 text-[#616161] max-w-[200px]">
                        <span className="line-clamp-1">
                          {order.items.map((i) => `${i.name} ×${i.quantity}`).join(', ')}
                        </span>
                      </td>

                      {/* Order & Delivery Dates */}
                      <td className="px-3 text-[12px] text-[#616161]">
                        <div>Order: {order.orderDate}</div>
                        {order.deliveryDate && <div>Delivery: {order.deliveryDate}</div>}
                      </td>

                      {/* Total */}
                      <td className="px-3 text-right font-[550] text-[#1A1A1A] tabular-nums">
                        ৳{order.totalAmount}
                      </td>

                      {/* Due */}
                      <td
                        className={`px-3 text-right font-[650] tabular-nums ${
                          hasDue ? 'text-[#8E0B21]' : 'text-[#616161]'
                        }`}
                      >
                        ৳{order.due}
                      </td>

                      {/* Status Badge */}
                      <td className="px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <StatusBadge
                          status={order.status}
                          interactive={true}
                          onChange={(newStatus) =>
                            updateOfficerOrderStatus(order.orderNumber, newStatus)
                          }
                        />
                      </td>

                      {/* Row Actions (Sticky Right) */}
                      <td
                        className="px-3 text-right sticky right-0 z-10 bg-white group-hover:bg-[#F7F7F7] border-l border-[#EBEBEB] shadow-[-2px_0_4px_rgba(0,0,0,0.03)]"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end space-x-1">
                          {canPay && (
                            <button
                              onClick={(e) => handlePayClick(e, order)}
                              title="Pay Due"
                              className="h-6 px-2 rounded bg-[#303030] hover:bg-[#1A1A1A] text-white text-[11px] font-[550] inline-flex items-center space-x-1 transition-colors border border-[#1A1A1A]"
                            >
                              <CreditCard className="w-3 h-3" />
                              <span>Pay</span>
                            </button>
                          )}
                          <button
                            onClick={() =>
                              onNavigate('print-slip', {
                                orderNumber: order.orderNumber,
                                category: 'Officer',
                              })
                            }
                            title="Cutting Slip"
                            className="p-1 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded"
                            aria-label="Cutting slip"
                          >
                            <Scissors className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() =>
                              onNavigate('print-invoice', {
                                orderNumber: order.orderNumber,
                                category: 'Officer',
                              })
                            }
                            title="Invoice"
                            className="p-1 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded"
                            aria-label="Invoice"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() =>
                              onNavigate('edit-officer-order', {
                                orderNumber: order.orderNumber,
                              })
                            }
                            title="Edit"
                            className="p-1 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded"
                            aria-label="Edit order"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteClick(e, order)}
                            title="Delete"
                            className="p-1 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FEE9E8] rounded"
                            aria-label="Delete order"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </PolarisCard>

      {/* Pay Modal - Apple Glass blur style */}
      <AnimatePresence>
        {payTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPayTargetOrder(null)}
              className="fixed inset-0 bg-black/45 backdrop-blur-md"
              aria-hidden="true"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-2xl p-6 border border-white/60 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] text-left"
              role="dialog"
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-200/60">
                <h3 className="text-base font-bold text-neutral-900">
                  Record Payment · Order #{payTargetOrder.orderNumber}
                </h3>
                <button
                  onClick={() => setPayTargetOrder(null)}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="py-4 space-y-3.5 text-sm">
                <p className="text-neutral-600">
                  Customer <strong className="text-neutral-900">{payTargetOrder.customerName}</strong> currently has an outstanding balance of:
                </p>
                <div className="p-4 bg-rose-50 border border-rose-200/80 rounded-xl text-center">
                  <span className="text-2xl font-extrabold text-rose-700 tabular-nums">
                    ৳{payTargetOrder.due}
                  </span>
                  <span className="block text-xs text-rose-600 mt-1 font-semibold">
                    Full balance remaining
                  </span>
                </div>
                <p className="text-xs text-neutral-500">
                  Confirming will mark this full amount as paid and clear the balance to ৳0.
                </p>
              </div>
              <div className="pt-3 border-t border-neutral-200/60 flex items-center justify-end gap-3">
                <button
                  onClick={() => setPayTargetOrder(null)}
                  className="min-h-[40px] px-4 rounded-xl bg-white border border-neutral-300 hover:bg-neutral-50 text-neutral-700 text-sm font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmPay}
                  className="min-h-[40px] px-5 rounded-xl btn-emerald text-sm font-semibold cursor-pointer"
                >
                  Confirm Payment
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Two-Step Delete Modal - Apple Glass blur style with DeleteWarningGlassIllustration */}
      <AnimatePresence>
        {deleteTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteTargetOrder(null)}
              className="fixed inset-0 bg-black/45 backdrop-blur-md"
              aria-hidden="true"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-2xl p-6 border border-white/60 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] text-left"
              role="dialog"
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-200/60">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-600 flex items-center justify-center">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900">
                    Delete Order #{deleteTargetOrder.orderNumber}?
                  </h3>
                </div>
                <button
                  onClick={() => setDeleteTargetOrder(null)}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-4 space-y-3.5 text-sm">
                {deleteStep === 1 ? (
                  <>
                    <p className="text-neutral-600">
                      Are you sure you want to delete Officer Order{' '}
                      <strong className="text-neutral-900">#{deleteTargetOrder.orderNumber}</strong> ({deleteTargetOrder.customerName})?
                    </p>
                    <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 text-xs text-neutral-600 leading-relaxed">
                      The order will be archived to <strong>Deleted History</strong> in Settings and can be restored at any time. Subsequent order numbers will shift down by 1.
                    </div>
                  </>
                ) : (
                  <div className="p-4 bg-rose-50/90 rounded-xl border border-rose-200 text-rose-900 text-xs space-y-1.5">
                    <div className="font-bold flex items-center space-x-1.5 text-rose-800 text-sm">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span>Confirm Final Deletion</span>
                    </div>
                    <p>
                      Order #{deleteTargetOrder.orderNumber} will be archived to Deleted History immediately.
                    </p>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-neutral-200/60 flex items-center justify-end gap-3">
                <button
                  onClick={() => setDeleteTargetOrder(null)}
                  className="min-h-[40px] px-4 rounded-xl bg-white border border-neutral-300 hover:bg-neutral-50 text-neutral-700 text-sm font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                {deleteStep === 1 ? (
                  <button
                    onClick={handleConfirmDeleteStep1}
                    className="min-h-[40px] px-5 rounded-xl btn-primary text-sm font-semibold cursor-pointer"
                  >
                    Continue
                  </button>
                ) : (
                  <button
                    onClick={handleConfirmDeleteStep2}
                    className="min-h-[40px] px-5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-sm font-semibold shadow-xs cursor-pointer active:translate-y-px transition-all"
                  >
                    Confirm Delete
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Quick Price/Rate Manager Shortcut Modal */}
      <ManageItemsModal
        isOpen={managePricesOpen}
        onClose={() => setManagePricesOpen(false)}
        initialTab="officer"
      />
    </PolarisPage>
  );
};
