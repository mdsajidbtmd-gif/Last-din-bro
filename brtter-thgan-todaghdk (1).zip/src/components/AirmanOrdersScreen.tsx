import React, { useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { AirmanOrder, OrderStatus } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import { ManageItemsModal } from './ManageItemsModal.tsx';
import { EmptyOrdersGlassIllustration } from './Illustrations.tsx';
import {
  Plus,
  Search,
  Printer,
  Edit2,
  Trash2,
  Truck,
  Plane,
  X,
  AlertCircle,
  Scissors,
  AlertTriangle,
  LayoutGrid,
  List,
  ChevronLeft,
  ChevronRight,
  Tag,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface AirmanOrdersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const AirmanOrdersScreen: React.FC<AirmanOrdersScreenProps> = ({ onNavigate }) => {
  const { state, loading, updateAirmanOrderStatus, deleteAirmanOrder } = useApp();

  const [selectedYear, setSelectedYear] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'All' | OrderStatus>('All');
  const [selectedUniformFilter, setSelectedUniformFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [managePricesOpen, setManagePricesOpen] = useState(false);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  const scrollTable = (direction: 'left' | 'right') => {
    if (tableContainerRef.current) {
      const offset = direction === 'left' ? -320 : 320;
      tableContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  // Delete Dialog State (Two-step delete)
  const [deleteTargetOrder, setDeleteTargetOrder] = useState<AirmanOrder | null>(null);
  const [deleteStep, setDeleteStep] = useState<1 | 2>(1);

  // Filter orders by Running Year first
  const yearOrders = useMemo(() => {
    if (selectedYear === 'All') return state.airmanOrders;
    return state.airmanOrders.filter((o) => o.runningYear === selectedYear);
  }, [state.airmanOrders, selectedYear]);

  // Dynamic Uniform Items from settings
  const uniformItemsList = useMemo(() => {
    return state.settings.airmanItems || [];
  }, [state.settings.airmanItems]);

  // Calculate counts for each uniform category in the current year
  const uniformCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    uniformItemsList.forEach((it) => {
      counts[it.name] = 0;
    });

    yearOrders.forEach((order) => {
      order.items.forEach((item) => {
        if (counts[item.name] !== undefined) {
          counts[item.name] += item.quantity || 1;
        } else {
          counts[item.name] = (counts[item.name] || 0) + (item.quantity || 1);
        }
      });
    });

    return counts;
  }, [yearOrders, uniformItemsList]);

  // Tab counts
  const tabCounts = useMemo(() => {
    return {
      All: yearOrders.length,
      Pending: yearOrders.filter((o) => o.status === 'Pending').length,
      'Cutting Slip – Done': yearOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      Delivered: yearOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [yearOrders]);

  // Filtered and Sorted Orders
  const filteredOrders = useMemo(() => {
    return yearOrders
      .filter((order) => {
        if (activeTab !== 'All' && order.status !== activeTab) return false;

        // Uniform item card filter
        if (selectedUniformFilter) {
          const hasItem = order.items.some((item) => item.name === selectedUniformFilter);
          if (!hasItem) return false;
        }

        // Search query: name, phone, BD number, order number or IV-Number
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesName = (order.customerName || '').toLowerCase().includes(q);
          const matchesPhone = (order.customerPhone || '').toLowerCase().includes(q);
          const matchesBd = order.customerBdNumber.toLowerCase().includes(q);
          const matchesOrderNum = String(order.orderNumber).includes(q) || `#${order.orderNumber}`.includes(q);
          const matchesIv = order.items.some((i) => (i.ivNumber || '').toLowerCase().includes(q));

          if (!matchesName && !matchesPhone && !matchesBd && !matchesOrderNum && !matchesIv) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortOrder === 'newest') return b.orderNumber - a.orderNumber;
        return a.orderNumber - b.orderNumber;
      });
  }, [yearOrders, activeTab, selectedUniformFilter, searchQuery, sortOrder]);

  const handleDeleteClick = (e: React.MouseEvent, order: AirmanOrder) => {
    e.stopPropagation();
    setDeleteTargetOrder(order);
    setDeleteStep(1);
  };

  const handleConfirmDeleteStep1 = () => {
    setDeleteStep(2);
  };

  const handleConfirmDeleteStep2 = () => {
    if (deleteTargetOrder) {
      deleteAirmanOrder(deleteTargetOrder.orderNumber);
      setDeleteTargetOrder(null);
      setDeleteStep(1);
    }
  };

  return (
    <PolarisPage
      title="Airman Orders"
      subtitle="Yearly bulk uniform batch orders with IV-Numbers and cutting slips"
      secondaryActions={[
        {
          label: 'Manage Prices',
          onClick: () => setManagePricesOpen(true),
          icon: <Tag className="w-3.5 h-3.5" />,
        },
        {
          label: 'Delivery',
          onClick: () => onNavigate('delivery'),
          icon: <Truck className="w-3.5 h-3.5" />,
        },
        {
          label: 'Officer Orders',
          onClick: () => onNavigate('orders'),
          icon: <Plane className="w-3.5 h-3.5" />,
        },
      ]}
      primaryAction={{
        label: 'New Airman Order',
        onClick: () => onNavigate('new-airman-order'),
        icon: <Plus className="w-3.5 h-3.5" />,
      }}
      fullWidth={true}
    >
      {/* Running Year Selector & Uniform Cards */}
      <div className="space-y-3">
        {/* Running Year Filter Bar */}
        <div className="flex items-center space-x-2">
          <span className="text-[13px] font-[550] text-[#616161]">Running Year:</span>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="h-7 px-2.5 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] font-[550] focus:outline-none focus:border-[#303030] cursor-pointer shadow-2xs"
          >
            <option value="All">All Years</option>
            {state.settings.runningYears.map((yr) => (
              <option key={yr} value={yr}>
                {yr}
              </option>
            ))}
          </select>
          {selectedUniformFilter && (
            <button
              onClick={() => setSelectedUniformFilter(null)}
              className="text-[12px] text-[#005BD3] hover:underline font-medium ml-2"
            >
              Clear {selectedUniformFilter} filter
            </button>
          )}
        </div>

        {/* Uniform Item Summary Cards (Pure Quantity, No Money) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {uniformItemsList.map((item) => {
            const count = uniformCounts[item.name] || 0;
            const isSelected = selectedUniformFilter === item.name;

            return (
              <div
                key={item.id}
                onClick={() =>
                  setSelectedUniformFilter((prev) => (prev === item.name ? null : item.name))
                }
                className={`p-3 bg-white rounded-xl border transition-all cursor-pointer shadow-[0_1px_0_rgba(26,26,26,0.07)] ${
                  isSelected
                    ? 'border-[#303030] ring-1 ring-[#303030] bg-[#FAFAFA]'
                    : 'border-[#E3E3E3] hover:border-[#8A8A8A]'
                }`}
              >
                <div className="text-[11px] font-[450] text-[#616161] truncate">
                  {item.name}
                </div>
                <div className="text-[18px] font-[650] text-[#1A1A1A] mt-1 tabular-nums">
                  {count} <span className="text-[11px] font-normal text-[#616161]">pcs</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Table Card */}
      <PolarisCard flush={true}>
        {/* Saved Views Tabs & Search/Sort */}
        <PolarisTabs
          tabs={[
            { id: 'All', label: 'All', count: tabCounts.All },
            { id: 'Pending', label: 'Pending', count: tabCounts.Pending },
            { id: 'Cutting Slip – Done', label: 'Cutting Slip – Done', count: tabCounts['Cutting Slip – Done'] },
            { id: 'Delivered', label: 'Delivered', count: tabCounts.Delivered },
          ]}
          selectedTab={activeTab}
          onSelectTab={(tabId) => setActiveTab(tabId as any)}
          tools={
            <div className="flex items-center space-x-2">
              <div className="relative w-48 sm:w-60">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
                <input
                  type="text"
                  placeholder="Search name, BD, IV-Number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-7 pl-8 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030] text-[#303030]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-[#8A8A8A] hover:text-[#303030]"
                    aria-label="Clear filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
                className="h-7 pl-2.5 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] focus:outline-none focus:border-[#303030] cursor-pointer"
                aria-label="Sort order"
              >
                <option value="newest">Newest first</option>
                <option value="oldest">Oldest first</option>
              </select>

              {/* Horizontal Scroll Assist Controls (Table Mode) */}
              {viewMode === 'table' && (
                <div className="flex items-center space-x-1 border border-[#E3E3E3] rounded-lg p-0.5 bg-white">
                  <button
                    type="button"
                    onClick={() => scrollTable('left')}
                    title="Slide table left"
                    className="p-1 hover:bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A] rounded transition-colors"
                    aria-label="Scroll table left"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] font-semibold text-[#8A8A8A] px-1 select-none">Slide</span>
                  <button
                    type="button"
                    onClick={() => scrollTable('right')}
                    title="Slide table right"
                    className="p-1 hover:bg-[#F1F1F1] text-[#616161] hover:text-[#1A1A1A] rounded transition-colors"
                    aria-label="Scroll table right"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* View Mode Toggle: Grid vs Table */}
              <div className="flex items-center bg-[#EBEBEB] p-0.5 rounded-lg border border-[#E3E3E3]">
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  title="Card View (No side-scroll)"
                  className={`p-1 rounded-md transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-white text-[#1A1A1A] shadow-2xs font-semibold'
                      : 'text-[#616161] hover:text-[#1A1A1A]'
                  }`}
                  aria-label="Grid view"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('table')}
                  title="List Table View (Sticky columns)"
                  className={`p-1 rounded-md transition-colors ${
                    viewMode === 'table'
                      ? 'bg-white text-[#1A1A1A] shadow-2xs font-semibold'
                      : 'text-[#616161] hover:text-[#1A1A1A]'
                  }`}
                  aria-label="Table view"
                >
                  <List className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          }
        />

        {/* Loading State */}
        {loading && (
          <div className="p-8 space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-12 bg-[#F1F1F1] rounded-lg animate-pulse" />
            ))}
          </div>
        )}

        {/* Empty State with Apple Glass styling */}
        {!loading && filteredOrders.length === 0 && (
          <div className="py-16 px-4 text-center flex flex-col items-center justify-center">
            <EmptyOrdersGlassIllustration category="Airman" className="w-28 h-28 mb-4" />
            <h3 className="text-base font-bold text-neutral-900 tracking-tight">No Airman Orders Found</h3>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1.5 max-w-sm leading-relaxed">
              {searchQuery || selectedUniformFilter || activeTab !== 'All'
                ? 'Try adjusting your search query, running year, or uniform tab filters.'
                : 'No airman trade orders recorded yet. Create your first batch uniform order.'}
            </p>
            {searchQuery || selectedUniformFilter || activeTab !== 'All' ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedUniformFilter(null);
                  setActiveTab('All');
                }}
                className="mt-5 min-h-[40px] px-5 rounded-xl bg-white hover:bg-neutral-50 text-neutral-800 text-sm font-semibold border border-neutral-300 shadow-xs cursor-pointer transition-all active:translate-y-px"
              >
                Reset Filters
              </button>
            ) : (
              <button
                onClick={() => onNavigate('new-airman-order')}
                className="mt-5 btn-primary text-sm shadow-[0_2px_8px_rgba(0,0,0,0.25)] cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Create First Airman Order</span>
              </button>
            )}
          </div>
        )}

        {/* Big Box Grid View */}
        {!loading && filteredOrders.length > 0 && viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5 p-4 sm:p-5 bg-[#F9FAFB] border-t border-[#E3E3E3]">
            {filteredOrders.map((order) => {
              const totalItemsCount = order.items.reduce((acc, i) => acc + (i.quantity || 1), 0);

              return (
                <div
                  key={order.id}
                  onClick={() =>
                    onNavigate('order-details', {
                      orderNumber: order.orderNumber,
                      category: 'Airman',
                    })
                  }
                  className="bg-white rounded-2xl border border-[#E3E3E3] hover:border-[#1A1A1A] p-5 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                >
                  {/* Top Header */}
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-[#1A1A1A] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                          #{order.orderNumber}
                        </div>
                        <div>
                          <h4 className="font-bold text-[#1A1A1A] text-[15px] leading-snug group-hover:text-[#005BD3] transition-colors line-clamp-1">
                            {order.customerName || `Airman BD/${order.customerBdNumber}`}
                          </h4>
                          <div className="text-xs text-[#616161] flex items-center gap-1.5 mt-0.5">
                            <span>Airman</span>
                            <span>·</span>
                            <span className="font-mono font-medium">BD/{order.customerBdNumber}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Status Badge & Running Year */}
                    <div className="flex flex-wrap items-center gap-2 mb-3.5" onClick={(e) => e.stopPropagation()}>
                      <StatusBadge
                        status={order.status}
                        interactive={true}
                        onChange={(newStatus) => updateAirmanOrderStatus(order.orderNumber, newStatus)}
                      />
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#EAF4FF] text-[#005BD3]">
                        {order.runningYear}
                      </span>
                    </div>

                    {/* Uniform Items & IV Numbers */}
                    <div className="py-2.5 border-y border-[#F0F0F0] mb-3.5 space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-[#8A8A8A] font-medium">Uniform items:</span>
                        <span className="font-semibold text-[#1A1A1A]">{totalItemsCount} pcs total</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {order.items.map((it, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center text-[11px] bg-[#F8F9FA] border border-[#E5E7EB] px-2 py-0.5 rounded-lg text-[#303030]"
                          >
                            <span className="font-medium">{it.name}</span>
                            <span className="text-[#8A8A8A] ml-1">×{it.quantity}</span>
                            {it.ivNumber && (
                              <span className="ml-1 text-[10px] text-[#005BD3] font-mono">IV:{it.ivNumber}</span>
                            )}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Order Meta */}
                    <div className="grid grid-cols-2 gap-2 text-xs text-[#616161] mb-2">
                      <div>
                        <span className="text-[#8A8A8A] text-[10px] block">Ribbon</span>
                        <span className="font-medium text-[#1A1A1A] truncate block">{order.ribbon || '—'}</span>
                      </div>
                      <div>
                        <span className="text-[#8A8A8A] text-[10px] block">Order Date</span>
                        <span className="font-mono text-[#1A1A1A]">{order.orderDate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Row */}
                  <div className="flex items-center justify-between pt-3 border-t border-[#F0F0F0]" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={() => onNavigate('print-slip', { orderNumber: order.orderNumber, category: 'Airman' })}
                      className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-xs font-semibold flex items-center space-x-1 transition-colors"
                    >
                      <Scissors className="w-3.5 h-3.5" />
                      <span>Cutting Slip</span>
                    </button>

                    <div className="flex items-center space-x-1">
                      <button
                        type="button"
                        onClick={() => onNavigate('edit-airman-order', { orderNumber: order.orderNumber })}
                        title="Edit"
                        className="p-1.5 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded-lg transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteClick(e, order)}
                        title="Delete"
                        className="p-1.5 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FEE9E8] rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* 54px Polaris IndexTable */}
        {!loading && filteredOrders.length > 0 && viewMode === 'table' && (
          <div ref={tableContainerRef} className="overflow-x-auto relative scroll-smooth overscroll-x-contain">
            <table className="w-full border-collapse text-left min-w-[760px]">
              <thead>
                <tr className="h-9 border-b border-[#E3E3E3] bg-[#FAFAFA] text-[13px] font-[450] text-[#616161]">
                  <th className="px-3 w-20 text-left sticky left-0 z-20 bg-[#FAFAFA] border-r border-[#EBEBEB] shadow-[2px_0_4px_rgba(0,0,0,0.03)]">
                    Order
                  </th>
                  <th className="px-3 text-left">Customer</th>
                  <th className="px-3 text-left">Items & IV-Number</th>
                  <th className="px-3 text-left">Year</th>
                  <th className="px-3 text-left">Order Date</th>
                  <th className="px-3 text-center w-36">Status</th>
                  <th className="px-3 text-right w-36 sticky right-0 z-20 bg-[#FAFAFA] border-l border-[#EBEBEB] shadow-[-2px_0_4px_rgba(0,0,0,0.03)]">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3E3E3] text-[13px]">
                {filteredOrders.map((order) => {
                  return (
                    <tr
                      key={order.id}
                      onClick={() =>
                        onNavigate('order-details', {
                          orderNumber: order.orderNumber,
                          category: 'Airman',
                        })
                      }
                      className="h-[54px] hover:bg-[#F7F7F7] cursor-pointer transition-colors group"
                    >
                      {/* Order # (Sticky Left) */}
                      <td className="px-3 font-[650] text-[#1A1A1A] sticky left-0 z-10 bg-white group-hover:bg-[#F7F7F7] border-r border-[#EBEBEB] shadow-[2px_0_4px_rgba(0,0,0,0.03)]">
                        #{order.orderNumber}
                      </td>

                      {/* Customer & BD */}
                      <td className="px-3">
                        <div className="font-[550] text-[#1A1A1A] line-clamp-1">
                          {order.customerName || `Airman ${order.customerBdNumber}`}
                        </div>
                        <div className="text-[11px] text-[#616161] mt-0.5">
                          BD: {order.customerBdNumber}
                        </div>
                      </td>

                      {/* Items & IV-Number */}
                      <td className="px-3 text-[#616161] max-w-[240px]">
                        <div className="line-clamp-1">
                          {order.items
                            .map((i) => `${i.name} ×${i.quantity} (IV:${i.ivNumber || '—'})`)
                            .join(', ')}
                        </div>
                      </td>

                      {/* Running Year */}
                      <td className="px-3 text-[12px] text-[#303030] font-[550]">
                        {order.runningYear}
                      </td>

                      {/* Order Date */}
                      <td className="px-3 text-[12px] text-[#616161]">
                        <div>{order.orderDate}</div>
                        <div className="text-[11px] text-[#8A8A8A]">Ribbon: {order.ribbon}</div>
                      </td>

                      {/* Status */}
                      <td className="px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <StatusBadge
                          status={order.status}
                          interactive={true}
                          onChange={(newStatus) =>
                            updateAirmanOrderStatus(order.orderNumber, newStatus)
                          }
                        />
                      </td>

                      {/* Actions (Sticky Right) */}
                      <td
                        className="px-3 text-right sticky right-0 z-10 bg-white group-hover:bg-[#F7F7F7] border-l border-[#EBEBEB] shadow-[-2px_0_4px_rgba(0,0,0,0.03)]"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            onClick={() =>
                              onNavigate('print-slip', {
                                orderNumber: order.orderNumber,
                                category: 'Airman',
                              })
                            }
                            title="Cutting Slip"
                            className="p-1 text-[#616161] hover:text-[#1A1A1A] hover:bg-[#EBEBEB] rounded"
                            aria-label="Cutting slip"
                          >
                            <Scissors className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() =>
                              onNavigate('edit-airman-order', {
                                orderNumber: order.orderNumber,
                              })
                            }
                            title="Edit"
                            className="p-1 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded"
                            aria-label="Edit order"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteClick(e, order)}
                            title="Delete"
                            className="p-1 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FEE9E8] rounded"
                            aria-label="Delete order"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </PolarisCard>

      {/* Two-Step Delete Modal - Apple Glass blur style */}
      <AnimatePresence>
        {deleteTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteTargetOrder(null)}
              className="fixed inset-0 bg-black/45 backdrop-blur-md"
              aria-hidden="true"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-2xl p-6 border border-white/60 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] text-left"
              role="dialog"
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-200/60">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-600 flex items-center justify-center">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900">
                    Delete Airman Order #{deleteTargetOrder.orderNumber}?
                  </h3>
                </div>
                <button
                  onClick={() => setDeleteTargetOrder(null)}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-4 space-y-3.5 text-sm">
                {deleteStep === 1 ? (
                  <>
                    <p className="text-neutral-600">
                      Are you sure you want to delete Airman Order{' '}
                      <strong className="text-neutral-900">#{deleteTargetOrder.orderNumber}</strong> (BD:{' '}
                      {deleteTargetOrder.customerBdNumber})?
                    </p>
                    <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 text-xs text-neutral-600 leading-relaxed">
                      The order will be archived to <strong>Deleted History</strong> in Settings and can be restored at any time. Subsequent order numbers will shift down by 1.
                    </div>
                  </>
                ) : (
                  <div className="p-4 bg-rose-50/90 rounded-xl border border-rose-200 text-rose-900 text-xs space-y-1.5">
                    <div className="font-bold flex items-center space-x-1.5 text-rose-800 text-sm">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span>Confirm Final Deletion</span>
                    </div>
                    <p>
                      Order #{deleteTargetOrder.orderNumber} will be archived to Deleted History immediately.
                    </p>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-neutral-200/60 flex items-center justify-end gap-3">
                <button
                  onClick={() => setDeleteTargetOrder(null)}
                  className="min-h-[40px] px-4 rounded-xl bg-white border border-neutral-300 hover:bg-neutral-50 text-neutral-700 text-sm font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                {deleteStep === 1 ? (
                  <button
                    onClick={handleConfirmDeleteStep1}
                    className="min-h-[40px] px-5 rounded-xl btn-primary text-sm font-semibold cursor-pointer"
                  >
                    Continue
                  </button>
                ) : (
                  <button
                    onClick={handleConfirmDeleteStep2}
                    className="min-h-[40px] px-5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-sm font-semibold shadow-xs cursor-pointer active:translate-y-px transition-all"
                  >
                    Confirm Delete
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Quick Price/Rate Manager Shortcut Modal */}
      <ManageItemsModal
        isOpen={managePricesOpen}
        onClose={() => setManagePricesOpen(false)}
        initialTab="airman"
      />
    </PolarisPage>
  );
};
