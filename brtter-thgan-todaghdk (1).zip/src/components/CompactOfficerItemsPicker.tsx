import React, { useState, useRef, useEffect } from 'react';
import { OfficerOrderItem, ItemDefinition } from '../types/index.ts';
import { ManageItemsModal } from './ManageItemsModal.tsx';
import {
  ChevronDown,
  Search,
  Plus,
  X,
  Edit3,
  Pencil,
  Trash2,
  Check,
} from 'lucide-react';

interface CompactOfficerItemsPickerProps {
  items: OfficerOrderItem[];
  onChange: (items: OfficerOrderItem[]) => void;
  availableItems: ItemDefinition[];
  editingRow: {
    catalogItem: ItemDefinition | null;
    quantity: number;
    price: number;
  };
  onEditingRowChange: (
    row: { catalogItem: ItemDefinition | null; quantity: number; price: number },
    touched: boolean
  ) => void;
  isEditingRowTouched: boolean;
}

export const CompactOfficerItemsPicker: React.FC<CompactOfficerItemsPickerProps> = ({
  items,
  onChange,
  availableItems,
  editingRow,
  onEditingRowChange,
  isEditingRowTouched,
}) => {
  // Staging row dropdown state
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // In-place edit state for an already saved item
  const [inPlaceEditIndex, setInPlaceEditIndex] = useState<number | null>(null);
  const [inPlaceItem, setInPlaceItem] = useState<ItemDefinition | null>(null);
  const [inPlaceQty, setInPlaceQty] = useState<number>(1);
  const [inPlaceDropdownOpen, setInPlaceDropdownOpen] = useState(false);
  const [inPlaceSearch, setInPlaceSearch] = useState('');
  const inPlaceDropdownRef = useRef<HTMLDivElement>(null);

  const [manageModalOpen, setManageModalOpen] = useState(false);

  // Initialize editing row if not set
  useEffect(() => {
    if (availableItems.length > 0 && !editingRow.catalogItem) {
      const first = availableItems[0];
      onEditingRowChange(
        {
          catalogItem: first,
          quantity: 1,
          price: first.price,
        },
        false
      );
    }
  }, [availableItems, editingRow.catalogItem, onEditingRowChange]);

  // Click outside listener for dropdowns
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (inPlaceDropdownRef.current && !inPlaceDropdownRef.current.contains(event.target as Node)) {
        setInPlaceDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredCatalog = availableItems.filter((i) =>
    i.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredInPlaceCatalog = availableItems.filter((i) =>
    i.name.toLowerCase().includes(inPlaceSearch.toLowerCase())
  );

  // Add staging row to saved items list
  const handleAddItem = () => {
    if (!editingRow.catalogItem) return;

    const newItem: OfficerOrderItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: editingRow.catalogItem.name,
      quantity: editingRow.quantity,
      price: editingRow.price,
      lineTotal: editingRow.quantity * editingRow.price,
    };

    onChange([...items, newItem]);

    // Reset staging row to default first item
    const first = availableItems[0] || editingRow.catalogItem;
    onEditingRowChange(
      {
        catalogItem: first,
        quantity: 1,
        price: first.price,
      },
      false
    );
  };

  const handleRemoveSavedItem = (index: number) => {
    if (inPlaceEditIndex === index) {
      setInPlaceEditIndex(null);
    }
    const updated = items.filter((_, idx) => idx !== index);
    onChange(updated);
  };

  const handleStartInPlaceEdit = (index: number) => {
    const target = items[index];
    const catItem = availableItems.find((i) => i.name === target.name) || {
      id: `custom-${index}`,
      name: target.name,
      price: target.price,
    };
    setInPlaceEditIndex(index);
    setInPlaceItem(catItem);
    setInPlaceQty(target.quantity);
    setInPlaceDropdownOpen(false);
  };

  const handleSaveInPlaceEdit = () => {
    if (inPlaceEditIndex === null || !inPlaceItem) return;
    const updated = [...items];
    updated[inPlaceEditIndex] = {
      ...updated[inPlaceEditIndex],
      name: inPlaceItem.name,
      quantity: inPlaceQty,
      price: inPlaceItem.price,
      lineTotal: inPlaceQty * inPlaceItem.price,
    };
    onChange(updated);
    setInPlaceEditIndex(null);
  };

  const handleCancelInPlaceEdit = () => {
    setInPlaceEditIndex(null);
  };

  const currentStagingTotal = (editingRow.price || 0) * (editingRow.quantity || 1);

  return (
    <div className="bg-white rounded-2xl border border-[#E3E3E3] p-4 sm:p-5 shadow-[0_1px_2px_rgba(26,26,26,0.06)] space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-[#F1F1F1]">
        <div className="flex items-center space-x-2">
          <h3 className="text-sm sm:text-base font-bold text-[#1A1A1A] tracking-tight">
            1. Items
          </h3>
          <span className="text-xs text-[#616161] font-medium">
            ({items.length} {items.length === 1 ? 'item saved' : 'items saved'})
          </span>
        </div>

        <button
          type="button"
          onClick={() => setManageModalOpen(true)}
          className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-[#005BD3] hover:text-[#0047A5] hover:bg-blue-50 transition-colors cursor-pointer"
          title="Edit item catalog and prices"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Manage Prices</span>
        </button>
      </div>

      {/* SAVED ITEMS LIST (ABOVE EDITING ROW) */}
      <div className="space-y-2">
        <label className="block text-[11px] font-bold text-[#616161] uppercase tracking-wider">
          Saved Items ({items.length})
        </label>

        {items.length === 0 ? (
          <div className="text-xs text-[#8A8A8A] italic py-2 px-3 bg-[#FAFBFB] rounded-xl border border-dashed border-[#E3E3E3]">
            No items saved yet. Configure the item below and tap "Add Item".
          </div>
        ) : (
          <div className="space-y-2">
            {items.map((item, index) => {
              if (inPlaceEditIndex === index) {
                // In-place edit row
                const inPlaceTotal = (inPlaceItem?.price || 0) * inPlaceQty;
                return (
                  <div
                    key={item.id || index}
                    className="p-3 bg-blue-50/50 border border-blue-300 rounded-xl space-y-2"
                  >
                    <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                      {/* In-place Item Dropdown */}
                      <div className="relative flex-1 min-w-[160px]" ref={inPlaceDropdownRef}>
                        <button
                          type="button"
                          onClick={() => setInPlaceDropdownOpen(!inPlaceDropdownOpen)}
                          className="w-full h-9 px-3 bg-white border border-[#D1D5DB] rounded-lg flex items-center justify-between text-xs font-semibold text-[#303030]"
                        >
                          <span className="truncate">{inPlaceItem?.name || 'Select item'}</span>
                          <ChevronDown className="w-4 h-4 text-[#8A8A8A] shrink-0 ml-1" />
                        </button>
                        {inPlaceDropdownOpen && (
                          <div className="absolute left-0 top-full mt-1 w-full sm:w-[280px] bg-white rounded-xl border border-[#E3E3E3] shadow-xl z-50 overflow-hidden">
                            <div className="p-2 border-b border-[#E3E3E3] bg-[#F7F7F7]">
                              <input
                                type="text"
                                value={inPlaceSearch}
                                onChange={(e) => setInPlaceSearch(e.target.value)}
                                placeholder="Search..."
                                autoFocus
                                className="w-full h-7 px-2 text-xs bg-white border border-[#D1D5DB] rounded"
                              />
                            </div>
                            <div className="max-h-48 overflow-y-auto divide-y divide-[#F1F1F1] py-1">
                              {filteredInPlaceCatalog.map((cItem) => (
                                <button
                                  key={cItem.id}
                                  type="button"
                                  onClick={() => {
                                    setInPlaceItem(cItem);
                                    setInPlaceDropdownOpen(false);
                                  }}
                                  className="w-full px-3 py-1.5 text-xs flex justify-between text-left hover:bg-blue-50"
                                >
                                  <span className="truncate">{cItem.name}</span>
                                  <span className="font-mono text-[#005BD3]">৳{cItem.price}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* In-place Qty */}
                      <div className="w-16 shrink-0">
                        <select
                          value={inPlaceQty}
                          onChange={(e) => setInPlaceQty(Number(e.target.value))}
                          className="w-full h-9 px-2 bg-white border border-[#D1D5DB] rounded-lg text-xs font-bold text-center"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((q) => (
                            <option key={q} value={q}>
                              {q}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* In-place Price */}
                      <div className="font-mono font-bold text-[#005BD3] text-sm tabular-nums shrink-0 px-1">
                        ৳{inPlaceTotal}
                      </div>

                      {/* In-place Actions */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={handleSaveInPlaceEdit}
                          className="h-9 px-3 bg-[#1A1A1A] hover:bg-black text-white text-xs font-bold rounded-lg shadow-2xs cursor-pointer"
                        >
                          Update Item
                        </button>
                        <button
                          type="button"
                          onClick={handleCancelInPlaceEdit}
                          className="h-9 px-2.5 bg-white border border-[#D1D5DB] hover:bg-[#F3F3F3] text-xs font-semibold rounded-lg text-[#616161] cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                );
              }

              // Normal saved compact line: item name, quantity, line price, pencil icon (edit), red delete icon
              return (
                <div
                  key={item.id || index}
                  className="flex items-center justify-between p-2.5 bg-[#FAFBFB] hover:bg-white border border-[#E3E3E3] rounded-xl text-xs transition-colors shadow-2xs"
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <span className="font-bold text-[#1A1A1A] truncate">{item.name}</span>
                    <span className="text-[#616161] font-medium shrink-0">
                      Qty: {item.quantity}
                    </span>
                    <span className="font-mono font-bold text-[#005BD3] tabular-nums shrink-0">
                      ৳{item.lineTotal || item.price * item.quantity}
                    </span>
                  </div>

                  <div className="flex items-center space-x-1 shrink-0 ml-2">
                    <button
                      type="button"
                      onClick={() => handleStartInPlaceEdit(index)}
                      className="p-1.5 text-[#616161] hover:text-[#005BD3] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit item"
                      aria-label={`Edit ${item.name}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSavedItem(index)}
                      className="p-1.5 text-[#8A8A8A] hover:text-[#8E0B21] hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete item"
                      aria-label={`Delete ${item.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* EDITING ROW (STAGING ROW BELOW SAVED ITEMS) */}
      <div className="pt-3 border-t border-[#E3E3E3] space-y-2.5">
        <div className="flex items-center justify-between">
          <label className="block text-[11px] font-bold text-[#1A1A1A] uppercase tracking-wider">
            Configure Item {isEditingRowTouched ? '(Unsaved Change)' : ''}
          </label>
          <span className="text-[11px] text-[#616161]">
            Tap "Add Item" to add to order
          </span>
        </div>

        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 relative">
          {/* Searchable Item Dropdown */}
          <div className="relative flex-1 min-w-[180px]" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="w-full h-10 px-3.5 bg-[#FAFAFA] hover:bg-white border border-[#D1D5DB] rounded-xl flex items-center justify-between text-xs font-semibold text-[#303030] transition-all focus:outline-none focus:ring-2 focus:ring-[#005BD3] cursor-pointer text-left shadow-2xs"
            >
              <span className="truncate">
                {editingRow.catalogItem?.name || 'Select item'}
              </span>
              <ChevronDown className="w-4 h-4 text-[#8A8A8A] shrink-0 ml-2" />
            </button>

            {dropdownOpen && (
              <div className="absolute left-0 top-full mt-1.5 w-full sm:w-[320px] bg-white rounded-2xl border border-[#E3E3E3] shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                <div className="p-2.5 border-b border-[#E3E3E3] bg-[#F7F7F7]">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search items..."
                      autoFocus
                      className="w-full h-8 pl-8 pr-7 text-xs bg-white border border-[#D1D5DB] rounded-lg text-[#303030] placeholder-[#8A8A8A] focus:outline-none focus:ring-1 focus:ring-[#005BD3]"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A] hover:text-[#303030]"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="max-h-[220px] overflow-y-auto divide-y divide-[#F1F1F1] py-1">
                  {filteredCatalog.map((catalogItem) => {
                    const isSelected = editingRow.catalogItem?.id === catalogItem.id;
                    return (
                      <button
                        key={catalogItem.id}
                        type="button"
                        onClick={() => {
                          onEditingRowChange(
                            {
                              catalogItem,
                              quantity: editingRow.quantity,
                              price: catalogItem.price,
                            },
                            true
                          );
                          setDropdownOpen(false);
                          setSearchQuery('');
                        }}
                        className={`w-full px-3.5 py-2 text-xs flex items-center justify-between text-left transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-blue-50/90 text-[#005BD3] font-bold'
                            : 'text-[#303030] hover:bg-[#F7F7F7] font-medium'
                        }`}
                      >
                        <span className="truncate pr-2">{catalogItem.name}</span>
                        <span className="text-xs font-mono tabular-nums shrink-0 text-[#005BD3] font-semibold">
                          ৳{catalogItem.price}
                        </span>
                      </button>
                    );
                  })}

                  {filteredCatalog.length === 0 && (
                    <div className="py-5 px-3 text-center text-xs text-[#8A8A8A]">
                      No matching items found
                    </div>
                  )}
                </div>

                <div className="p-2 border-t border-[#E3E3E3] bg-[#F7F7F7]">
                  <button
                    type="button"
                    onClick={() => {
                      setDropdownOpen(false);
                      setManageModalOpen(true);
                    }}
                    className="w-full py-1.5 px-3 rounded-lg text-xs font-semibold text-[#303030] hover:text-[#005BD3] hover:bg-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-transparent hover:border-[#E3E3E3]"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Manage Items</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quantity Dropdown (1 to 10) */}
          <div className="w-20 shrink-0">
            <select
              value={editingRow.quantity}
              onChange={(e) => {
                const q = Number(e.target.value);
                onEditingRowChange(
                  {
                    ...editingRow,
                    quantity: q,
                  },
                  true
                );
              }}
              className="w-full h-10 px-2.5 bg-[#FAFAFA] hover:bg-white border border-[#D1D5DB] rounded-xl text-xs font-bold text-[#303030] focus:outline-none focus:ring-2 focus:ring-[#005BD3] cursor-pointer text-center shadow-2xs"
              aria-label="Item quantity"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((q) => (
                <option key={q} value={q}>
                  {q}
                </option>
              ))}
            </select>
          </div>

          {/* Live Row Price */}
          <div className="shrink-0 px-2 flex items-center">
            <span className="text-base sm:text-lg font-bold font-mono text-[#005BD3] tabular-nums">
              ৳{currentStagingTotal}
            </span>
          </div>

          {/* Add Item Button (below / inline) */}
          <button
            type="button"
            onClick={handleAddItem}
            className="h-10 px-4 bg-[#1A1A1A] hover:bg-black active:scale-95 text-white border border-[#303030] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-[0_2px_4px_rgba(0,0,0,0.15)] cursor-pointer shrink-0"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Add Item</span>
          </button>
        </div>
      </div>

      <ManageItemsModal
        isOpen={manageModalOpen}
        onClose={() => setManageModalOpen(false)}
        initialTab="officer"
      />
    </div>
  );
};
