import React from 'react';
import { ArrowLeft } from 'lucide-react';

export interface ActionItem {
  label?: string;
  content?: string;
  onClick?: () => void;
  onAction?: () => void;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface PolarisPageProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  backAction?: () => void;
  primaryAction?: ActionItem;
  secondaryActions?: ActionItem[];
  children: React.ReactNode;
  fullWidth?: boolean;
}

export const PolarisPage: React.FC<PolarisPageProps> = ({
  title,
  subtitle,
  badge,
  backAction,
  primaryAction,
  secondaryActions = [],
  children,
  fullWidth = false,
}) => {
  return (
    <div className="min-h-full text-[#303030] pb-12">
      {/* Max Width Container */}
      <div className={`mx-auto space-y-4 ${fullWidth ? 'max-w-7xl' : 'max-w-[1000px]'}`}>
        {/* Page Header (Title 20/28, 650 weight) */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-1">
          {/* Left: Back Arrow + Title + Badge */}
          <div className="flex items-center space-x-3">
            {backAction && (
              <button
                onClick={backAction}
                className="w-7 h-7 rounded-[8px] flex items-center justify-center text-[#303030] hover:bg-black/5 border border-[#E3E3E3] bg-white transition-colors cursor-pointer shrink-0"
                aria-label="Back"
              >
                <ArrowLeft className="w-4 h-4 stroke-[2]" />
              </button>
            )}
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-[20px] leading-[28px] font-[650] text-[#1A1A1A] tracking-normal">
                  {title}
                </h1>
                {badge && <div className="shrink-0">{badge}</div>}
              </div>
              {subtitle && (
                <p className="text-[13px] leading-[20px] text-[#616161] font-[450] mt-0.5">
                  {subtitle}
                </p>
              )}
            </div>
          </div>

          {/* Right: Actions Cluster (High-contrast Primary & Secondary buttons) */}
          {(secondaryActions.length > 0 || primaryAction) && (
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              {secondaryActions.map((action, idx) => {
                const clickHandler = action.onClick || action.onAction;
                const text = action.label || action.content;
                return (
                  <button
                    key={idx}
                    onClick={clickHandler}
                    disabled={action.disabled}
                    className="min-h-[38px] sm:min-h-[40px] px-3.5 sm:px-4 rounded-xl bg-white hover:bg-neutral-50 active:bg-neutral-100 text-[#1F2937] text-[13px] sm:text-sm font-semibold inline-flex items-center space-x-1.5 border border-[#D1D5DB] shadow-[0_1px_3px_rgba(0,0,0,0.06)] hover:shadow-[0_2px_6px_rgba(0,0,0,0.09)] transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer active:translate-y-px"
                  >
                    {action.icon && <span className="w-4 h-4 text-[#4B5563]">{action.icon}</span>}
                    <span>{text}</span>
                  </button>
                );
              })}

              {primaryAction && (() => {
                const clickHandler = primaryAction.onClick || primaryAction.onAction;
                const text = primaryAction.label || primaryAction.content;
                return (
                  <button
                    onClick={clickHandler}
                    disabled={primaryAction.disabled}
                    className="min-h-[38px] sm:min-h-[40px] px-4 sm:px-5 rounded-xl bg-gradient-to-b from-[#2B2B2B] to-[#141414] hover:from-[#383838] hover:to-[#222222] text-white text-[13px] sm:text-sm font-semibold inline-flex items-center space-x-2 border border-[#383838] shadow-[0_2px_6px_rgba(0,0,0,0.22),inset_0_1px_0_rgba(255,255,255,0.18)] hover:shadow-[0_4px_12px_rgba(0,0,0,0.28)] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-all active:translate-y-px"
                  >
                    {primaryAction.icon && <span className="w-4 h-4 stroke-[2.2]">{primaryAction.icon}</span>}
                    <span>{text}</span>
                  </button>
                );
              })()}
            </div>
          )}
        </div>

        {/* Content Region */}
        <div className="space-y-4">{children}</div>
      </div>
    </div>
  );
};
