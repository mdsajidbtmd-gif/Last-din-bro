import React, { useState } from 'react';
import { Plus, User, Check, Scissors, ChevronRight } from 'lucide-react';
import { StaffWorker } from '../../types/index.ts';

interface AvatarGroupEditableProps {
  workers: StaffWorker[];
  maxDisplay?: number;
  onSelectWorker?: (worker: StaffWorker) => void;
  onManageStaff?: () => void;
  className?: string;
}

const PASTEL_AVATARS = [
  { bg: 'bg-[#cce7ff]', text: 'text-[#0069e0]', border: 'border-[#93c5fd]' },
  { bg: 'bg-[#f1e6ff]', text: 'text-[#7e22ce]', border: 'border-[#d8b4fe]' },
  { bg: 'bg-[#d3f6e3]', text: 'text-[#047857]', border: 'border-[#86efac]' },
  { bg: 'bg-[#ffd1b8]', text: 'text-[#c2410c]', border: 'border-[#fdba74]' },
  { bg: 'bg-[#fff2be]', text: 'text-[#a16207]', border: 'border-[#fde047]' },
  { bg: 'bg-[#c2e9ff]', text: 'text-[#0284c7]', border: 'border-[#7dd3fc]' },
];

export const AvatarGroupEditable: React.FC<AvatarGroupEditableProps> = ({
  workers,
  maxDisplay = 4,
  onSelectWorker,
  onManageStaff,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [hoveredWorker, setHoveredWorker] = useState<StaffWorker | null>(null);

  const displayWorkers = workers.slice(0, maxDisplay);
  const overflowCount = Math.max(0, workers.length - maxDisplay);

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      {/* Overlapping Avatar Stack */}
      <div className="flex items-center -space-x-2.5 overflow-visible">
        {displayWorkers.map((worker, index) => {
          const style = PASTEL_AVATARS[index % PASTEL_AVATARS.length];
          const initials = worker.name
            .split(' ')
            .map((n: string) => n[0])
            .join('')
            .slice(0, 2)
            .toUpperCase();

          return (
            <div
              key={worker.id}
              className="relative group cursor-pointer"
              onMouseEnter={() => setHoveredWorker(worker)}
              onMouseLeave={() => setHoveredWorker(null)}
              onClick={() => onSelectWorker?.(worker)}
            >
              <div
                className={`w-9 h-9 rounded-full ${style.bg} ${style.text} flex items-center justify-center font-bold text-xs ring-2 ring-white shadow-sm hover:scale-115 hover:z-30 transition-all duration-200 select-none`}
                title={`${worker.name} (${worker.banglaName || 'Tailor'})`}
              >
                {initials}
              </div>

              {/* Hover Tooltip Card */}
              {hoveredWorker?.id === worker.id && !isOpen && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-44 bg-[#0a0d12] text-white p-2.5 rounded-2xl shadow-xl z-50 pointer-events-none text-left animate-in fade-in zoom-in-95 duration-150">
                  <div className="text-xs font-semibold">{worker.name}</div>
                  <div className="text-[10px] text-gray-300">{worker.banglaName || 'Master Tailor'}</div>
                  <div className="mt-1 pt-1 border-t border-white/10 flex justify-between text-[10px] text-[#7dd3fc]">
                    <span>Status:</span>
                    <span className="font-semibold">{worker.active ? 'Active on Duty' : 'On Leave'}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Overflow Pill */}
        {overflowCount > 0 && (
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="w-9 h-9 rounded-full bg-[#ebf5ff] text-[#0069e0] border border-[#93c5fd] ring-2 ring-white font-semibold text-xs flex items-center justify-center hover:scale-110 hover:z-20 transition-all cursor-pointer shadow-sm select-none"
            title={`View all ${workers.length} staff`}
          >
            +{overflowCount}
          </button>
        )}

        {/* Interactive Add/Manage Pill */}
        <button
          type="button"
          onClick={() => (onManageStaff ? onManageStaff() : setIsOpen(!isOpen))}
          className="ml-3.5 h-8 px-3 rounded-full bg-white/90 hover:bg-white text-[#0a0d12] border border-[#dbeafe] hover:border-[#0069e0] ring-1 ring-white/60 shadow-sm flex items-center gap-1.5 text-xs font-medium transition-all hover:shadow hover:scale-105 active:scale-95 cursor-pointer"
          title="Manage tailors & staff"
        >
          <Plus className="w-3.5 h-3.5 text-[#0069e0]" />
          <span>Staff</span>
        </button>
      </div>

      {/* Editable Popover Menu */}
      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 top-full mt-2 w-72 bg-[#fafdff] rounded-[24px] shadow-[0_12px_32px_rgba(4,69,144,0.12)] border border-[#dbeafe] p-3.5 z-50 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#ebf5ff]">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#0a0d12]">
                <Scissors className="w-3.5 h-3.5 text-[#0069e0]" />
                <span>Tailors & Staff ({workers.length})</span>
              </div>
              {onManageStaff && (
                <button
                  type="button"
                  onClick={() => {
                    setIsOpen(false);
                    onManageStaff();
                  }}
                  className="text-[11px] text-[#0069e0] hover:underline font-semibold"
                >
                  Manage All
                </button>
              )}
            </div>

            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {workers.map((w, i) => {
                const style = PASTEL_AVATARS[i % PASTEL_AVATARS.length];
                return (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => {
                      onSelectWorker?.(w);
                      setIsOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-[#ebf5ff]/70 text-left transition-colors group"
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-7 h-7 rounded-full ${style.bg} ${style.text} flex items-center justify-center text-[10px] font-bold`}
                      >
                        {w.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-[#0a0d12] group-hover:text-[#0069e0]">
                          {w.name}
                        </div>
                        <div className="text-[10px] text-[#535862]">
                          {w.banglaName || 'Tailor Master'} · {w.active ? 'Active' : 'Inactive'}
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-[#93979f] group-hover:text-[#0069e0]" />
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
