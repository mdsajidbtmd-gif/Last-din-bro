import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import {
  AirmanItemDefinition,
  AirmanOrder,
  AppState,
  Customer,
  DeletedAirmanOrder,
  DeletedOfficerOrder,
  Draft,
  ItemDefinition,
  OfficerOrder,
  PaymentRecord,
  ShopSettings,
  StaffWorker,
  WorkerEntryRow,
  WorkerPayment,
  WorkItemDefinition,
  DiscountType,
  SlipType,
  OrderStatus,
} from '../types/index.ts';
import { DEFAULT_SETTINGS } from '../utils/starterData.ts';
import {
  calculateDiscount,
  calculateDue,
  formatDate,
  normalizeBdNumber,
  renumberOrdersOnDelete,
  renumberOrdersOnRestore,
  validateAirmanIvNumbers,
  validateRunningYear,
  getItemSlipType,
} from '../utils/logic.ts';
import { db } from '../firebase.ts';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface AppContextType {
  state: AppState;
  loading: boolean;
  error: string | null;
  // Officer order actions
  saveOfficerOrder: (
    data: Omit<OfficerOrder, 'id' | 'orderNumber' | 'category' | 'createdAt' | 'updatedAt' | 'due' | 'discountAmount'> & {
      id?: string;
      orderNumber?: number;
    },
    draftIdToClean?: string
  ) => { success: boolean; error?: string; order?: OfficerOrder };
  updateOfficerOrderStatus: (orderNumber: number, newStatus: OfficerOrder['status']) => void;
  confirmOfficerDelivery: (params: {
    orderNumber: number;
    deliveredDate: string;
    discountValue: string;
    discountType: DiscountType;
    discountAmount: number;
    cashReceive: number;
    receiverName: string;
    receiverPhone: string;
  }) => { success: boolean; error?: string };
  deleteOfficerOrder: (orderNumber: number) => void;
  restoreOfficerOrder: (deletedAt: string) => { success: boolean; error?: string };
  recordOfficerPayment: (orderNumber: number, amount: number) => { success: boolean; error?: string };

  // Airman order actions
  saveAirmanOrder: (
    data: Omit<AirmanOrder, 'id' | 'orderNumber' | 'category' | 'createdAt' | 'updatedAt'> & {
      id?: string;
      orderNumber?: number;
    },
    draftIdToClean?: string
  ) => { success: boolean; error?: string; order?: AirmanOrder };
  updateAirmanOrderStatus: (orderNumber: number, newStatus: AirmanOrder['status']) => void;
  confirmAirmanDelivery: (params: {
    orderNumber: number;
    deliveredDate: string;
    receiverName: string;
    receiverPhone: string;
  }) => { success: boolean; error?: string };
  deleteAirmanOrder: (orderNumber: number) => void;
  restoreAirmanOrder: (deletedAt: string) => { success: boolean; error?: string };

  // Draft actions
  saveDraft: (draft: Omit<Draft, 'id' | 'lastSaved'> & { id?: string }) => Draft;
  deleteDraft: (draftId: string) => void;

  // Customer actions
  addCustomer: (data: { category: 'Officer' | 'Airman'; bdNumber: string; name: string; phone: string }) => {
    success: boolean;
    error?: string;
  };
  updateCustomer: (
    bdNumber: string,
    category: 'Officer' | 'Airman',
    data: { name: string; phone: string }
  ) => { success: boolean; error?: string };
  deleteCustomer: (bdNumber: string, category: 'Officer' | 'Airman') => { success: boolean; error?: string };

  // Worker actions
  addWorker: (name: string, banglaName: string) => { success: boolean; error?: string; worker?: StaffWorker };
  updateWorker: (id: string, updates: Partial<StaffWorker>) => { success: boolean; error?: string };
  deleteWorker: (id: string) => { success: boolean; error?: string };

  // Worker sheet & payments
  saveWorkerRows: (workerId: string, rows: WorkerEntryRow[]) => { success: boolean; error?: string };
  addWorkerPayment: (payment: Omit<WorkerPayment, 'id' | 'createdAt'>) => { success: boolean; error?: string };
  updateWorkerPayment: (id: string, updates: Partial<WorkerPayment>) => { success: boolean; error?: string };
  deleteWorkerPayment: (id: string) => void;

  // Settings & Lists
  updateSettings: (newSettings: Partial<ShopSettings>) => void;
  addRunningYear: (year: string) => { success: boolean; error?: string; normalized?: string };
  addOfficerItem: (name: string, price: number, category?: string, slipType?: SlipType) => { success: boolean; error?: string };
  updateOfficerItem: (id: string, name: string, price: number, category?: string, slipType?: SlipType) => { success: boolean; error?: string };
  deleteOfficerItem: (id: string) => { success: boolean; error?: string };
  batchUpdateOfficerItems: (items: ItemDefinition[]) => { success: boolean; error?: string };
  addAirmanItem: (name: string, slipType?: SlipType) => { success: boolean; error?: string };
  updateAirmanItem: (id: string, name: string, slipType?: SlipType) => { success: boolean; error?: string };
  deleteAirmanItem: (id: string) => { success: boolean; error?: string };
  addWorkerItem: (name: string, rate: number) => { success: boolean; error?: string };
  updateWorkerItem: (id: string, name: string, rate: number) => { success: boolean; error?: string };
  deleteWorkerItem: (id: string) => { success: boolean; error?: string };
  restoreFullBackup: (backupState: AppState) => Promise<boolean>;
  refreshData: () => Promise<void>;
  resetToFreshState: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'tailor_shop_state_cache';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (cached) {
        const parsed = JSON.parse(cached);
        return {
          officerOrders: parsed.officerOrders || [],
          airmanOrders: parsed.airmanOrders || [],
          deletedOfficerOrders: parsed.deletedOfficerOrders || [],
          deletedAirmanOrders: parsed.deletedAirmanOrders || [],
          customers: parsed.customers || [],
          drafts: parsed.drafts || [],
          workers: parsed.workers || [],
          workerRows: parsed.workerRows || [],
          workerPayments: parsed.workerPayments || [],
          settings: {
            ...DEFAULT_SETTINGS,
            ...(parsed.settings || {}),
            branchValues: parsed.settings?.branchValues || DEFAULT_SETTINGS.branchValues,
            airmanItems: parsed.settings?.airmanItems || DEFAULT_SETTINGS.airmanItems,
            workItems: parsed.settings?.workItems && parsed.settings.workItems.length >= 50
              ? parsed.settings.workItems
              : DEFAULT_SETTINGS.workItems,
            ribbonValues: parsed.settings?.ribbonValues && parsed.settings.ribbonValues.length >= 10
              ? parsed.settings.ribbonValues
              : DEFAULT_SETTINGS.ribbonValues,
            runningYears: parsed.settings?.runningYears && parsed.settings.runningYears.length >= 3
              ? parsed.settings.runningYears
              : DEFAULT_SETTINGS.runningYears,
          },
        };
      }
    } catch {}
    return {
      officerOrders: [],
      airmanOrders: [],
      deletedOfficerOrders: [],
      deletedAirmanOrders: [],
      customers: [],
      drafts: [],
      workers: [],
      workerRows: [],
      workerPayments: [],
      settings: DEFAULT_SETTINGS,
    };
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Sync to Firestore cloud, local backend, and cache
  const persistState = useCallback(async (newState: AppState) => {
    setState(newState);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newState));
      await fetch('/api/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newState),
      });

      // Synchronize to Firebase Firestore cloud database
      setDoc(
        doc(db, 'settings', 'shop_state'),
        {
          officerOrders: newState.officerOrders,
          airmanOrders: newState.airmanOrders,
          deletedOfficerOrders: newState.deletedOfficerOrders,
          deletedAirmanOrders: newState.deletedAirmanOrders,
          customers: newState.customers,
          workers: newState.workers,
          workerRows: newState.workerRows,
          workerPayments: newState.workerPayments,
          settings: newState.settings,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      ).catch((err) => {
        console.warn('Firestore cloud sync notice:', err.message);
      });
    } catch (err) {
      console.warn('Backend sync failed, state kept in local cache:', err);
    }
  }, []);

  const refreshData = useCallback(async () => {
    try {
      // 1. First attempt to load state from Firebase Firestore
      let data: any = null;
      try {
        const firestoreSnap = await getDoc(doc(db, 'settings', 'shop_state'));
        if (firestoreSnap.exists()) {
          data = firestoreSnap.data();
        }
      } catch (fErr) {
        console.warn('Firestore read notice, trying local API:', fErr);
      }

      // 2. If no firestore doc yet, fallback to local backend API
      if (!data) {
        const res = await fetch('/api/state');
        if (res.ok) {
          data = await res.json();
        }
      }

      if (data) {
        const merged: AppState = {
          officerOrders: data.officerOrders || [],
          airmanOrders: data.airmanOrders || [],
          deletedOfficerOrders: data.deletedOfficerOrders || [],
          deletedAirmanOrders: data.deletedAirmanOrders || [],
          customers: data.customers || [],
          drafts: data.drafts || [],
          workers: data.workers || [],
          workerRows: data.workerRows || [],
          workerPayments: data.workerPayments || [],
          settings: {
            ...DEFAULT_SETTINGS,
            ...(data.settings || {}),
            branchValues: data.settings?.branchValues || DEFAULT_SETTINGS.branchValues,
            airmanItems: data.settings?.airmanItems || DEFAULT_SETTINGS.airmanItems,
            workItems: data.settings?.workItems && data.settings.workItems.length >= 50
              ? data.settings.workItems
              : DEFAULT_SETTINGS.workItems,
            ribbonValues: data.settings?.ribbonValues && data.settings.ribbonValues.length >= 10
              ? data.settings.ribbonValues
              : DEFAULT_SETTINGS.ribbonValues,
            runningYears: data.settings?.runningYears && data.settings.runningYears.length >= 3
              ? data.settings.runningYears
              : DEFAULT_SETTINGS.runningYears,
          },
        };
        setState(merged);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
      }
    } catch (err) {
      console.warn('Could not fetch state from server, using local state:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const resetToFreshState = useCallback(async () => {
    const clean: AppState = {
      officerOrders: [],
      airmanOrders: [],
      deletedOfficerOrders: [],
      deletedAirmanOrders: [],
      customers: [],
      drafts: [],
      workers: [],
      workerRows: [],
      workerPayments: [],
      settings: DEFAULT_SETTINGS,
    };
    await persistState(clean);
  }, [persistState]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Sync Customer
  const syncCustomer = (
    category: 'Officer' | 'Airman',
    bdNumber: string,
    name: string,
    phone: string,
    currentCustomers: Customer[]
  ) => {
    const norm = normalizeBdNumber(bdNumber) || bdNumber.trim();
    if (!norm) return currentCustomers;

    const existingIndex = currentCustomers.findIndex(
      (c) =>
        c.category === category &&
        (normalizeBdNumber(c.bdNumber).toUpperCase() === norm.toUpperCase() ||
          c.bdNumber.trim().toUpperCase() === norm.toUpperCase())
    );

    if (existingIndex >= 0) {
      const existing = currentCustomers[existingIndex];
      const updatedPhone = existing.phone ? existing.phone : phone;
      const updatedList = [...currentCustomers];
      updatedList[existingIndex] = {
        ...existing,
        phone: updatedPhone,
      };
      return updatedList;
    } else {
      const newCust: Customer = {
        id: `cust-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        category,
        bdNumber: norm,
        name: name.trim() || (category === 'Airman' ? `Airman ${norm}` : norm),
        phone: phone.trim(),
        createdAt: new Date().toISOString(),
      };
      return [newCust, ...currentCustomers];
    }
  };

  // --- OFFICER ORDER ACTIONS ---
  const saveOfficerOrder = useCallback(
    (orderData: any, draftIdToClean?: string) => {
      const missing: string[] = [];
      if (!orderData.customerName || !orderData.customerName.trim()) missing.push('customer name');
      if (!orderData.customerBdNumber || !orderData.customerBdNumber.trim()) missing.push('BD number');
      if (!orderData.items || orderData.items.length === 0) missing.push('at least one item');

      if (missing.length > 0) {
        return {
          success: false,
          error: `Please add the ${missing.join(' and ')}.`,
        };
      }

      const normBd = normalizeBdNumber(orderData.customerBdNumber) || orderData.customerBdNumber.trim();

      // Check BD number rule: if existing customer, saved name is used
      const existingCust = state.customers.find(
        (c) =>
          c.category === 'Officer' &&
          (normalizeBdNumber(c.bdNumber).toUpperCase() === normBd.toUpperCase() ||
            c.bdNumber.trim().toUpperCase() === normBd.toUpperCase())
      );
      const finalName = existingCust ? existingCust.name : orderData.customerName.trim();

      // Discount calculation
      const { amount: discountAmount, type: discountType } = calculateDiscount(
        orderData.totalAmount,
        orderData.discountValue,
        state.settings.defaultDiscountType
      );

      // Payments & money received check
      const payments: PaymentRecord[] = orderData.payments || [];
      const alreadyReceived =
        (Number(orderData.advance) || 0) + payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      const netTotal = orderData.totalAmount - discountAmount;

      if (alreadyReceived > netTotal) {
        return {
          success: false,
          error: 'The money already received is more than the total. Please check the amounts.',
        };
      }

      const due = calculateDue(orderData.totalAmount, discountAmount, Number(orderData.advance) || 0, payments);

      let updatedOrders = [...state.officerOrders];
      let savedOrder: OfficerOrder;

      const isEdit =
        typeof orderData.orderNumber === 'number' &&
        orderData.orderNumber > 0 &&
        updatedOrders.some((o) => o.orderNumber === orderData.orderNumber);

      if (isEdit) {
        const index = updatedOrders.findIndex((o) => o.orderNumber === orderData.orderNumber);
        if (index === -1) {
          return { success: false, error: 'Order not found for editing.' };
        }
        savedOrder = {
          ...updatedOrders[index],
          ...orderData,
          customerBdNumber: normBd,
          customerName: finalName,
          discountAmount,
          discountType,
          due,
          updatedAt: new Date().toISOString(),
        };
        updatedOrders[index] = savedOrder;
      } else {
        const maxNumber = updatedOrders.reduce((max, o) => Math.max(max, o.orderNumber || 0), 0);
        const nextNumber = maxNumber + 1;

        savedOrder = {
          ...orderData,
          id: `off-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          orderNumber: nextNumber,
          category: 'Officer',
          customerBdNumber: normBd,
          customerName: finalName,
          status: 'Pending',
          discountAmount,
          discountType,
          payments: [],
          due,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        updatedOrders = [savedOrder, ...updatedOrders];
      }

      // Sync customer
      const updatedCustomers = syncCustomer(
        'Officer',
        normBd,
        finalName,
        orderData.customerPhone || '',
        state.customers
      );

      // Clean draft if applicable
      const updatedDrafts = draftIdToClean ? state.drafts.filter((d) => d.id !== draftIdToClean) : state.drafts;

      const newState: AppState = {
        ...state,
        officerOrders: updatedOrders,
        customers: updatedCustomers,
        drafts: updatedDrafts,
      };

      persistState(newState);
      return { success: true, order: savedOrder };
    },
    [state, persistState]
  );

  const updateOfficerOrderStatus = useCallback(
    (orderNumber: number, newStatus: OfficerOrder['status']) => {
      const todayStr = formatDate();
      const updatedOrders = state.officerOrders.map((o) => {
        if (o.orderNumber !== orderNumber) return o;
        const isNowDelivered = newStatus === 'Delivered';
        return {
          ...o,
          status: newStatus,
          deliveredDate: isNowDelivered ? (o.deliveredDate || todayStr) : undefined,
          receiverName: isNowDelivered ? o.receiverName : undefined,
          receiverPhone: isNowDelivered ? o.receiverPhone : undefined,
          updatedAt: new Date().toISOString(),
        };
      });

      persistState({ ...state, officerOrders: updatedOrders });
    },
    [state, persistState]
  );

  const confirmOfficerDelivery = useCallback(
    (params: {
      orderNumber: number;
      deliveredDate: string;
      discountValue: string;
      discountType: DiscountType;
      discountAmount: number;
      cashReceive: number;
      receiverName: string;
      receiverPhone: string;
    }) => {
      const targetOrder = state.officerOrders.find((o) => o.orderNumber === params.orderNumber);
      if (!targetOrder) return { success: false, error: 'Order not found.' };

      let updatedPayments = [...(targetOrder.payments || [])];
      if (params.cashReceive > 0) {
        updatedPayments.push({
          id: `pay-${Date.now()}`,
          amount: params.cashReceive,
          date: params.deliveredDate,
        });
      }

      const newDue = calculateDue(
        targetOrder.totalAmount,
        params.discountAmount,
        targetOrder.advance,
        updatedPayments
      );

      const updatedOrders = state.officerOrders.map((o) => {
        if (o.orderNumber !== params.orderNumber) return o;
        return {
          ...o,
          status: 'Delivered' as OrderStatus,
          deliveredDate: params.deliveredDate,
          receiverName: params.receiverName,
          receiverPhone: params.receiverPhone,
          discountValue: params.discountValue,
          discountType: params.discountType,
          discountAmount: params.discountAmount,
          payments: updatedPayments,
          due: newDue,
          updatedAt: new Date().toISOString(),
        };
      });

      persistState({ ...state, officerOrders: updatedOrders });
      return { success: true };
    },
    [state, persistState]
  );

  const deleteOfficerOrder = useCallback(
    (orderNumber: number) => {
      const orderToDelete = state.officerOrders.find((o) => o.orderNumber === orderNumber);
      if (!orderToDelete) return;

      const deletedRecord: DeletedOfficerOrder = {
        order: orderToDelete,
        deletedAt: new Date().toISOString(),
      };

      const renumbered = renumberOrdersOnDelete(state.officerOrders, orderNumber);
      persistState({
        ...state,
        officerOrders: renumbered,
        deletedOfficerOrders: [deletedRecord, ...(state.deletedOfficerOrders || [])],
      });
    },
    [state, persistState]
  );

  const restoreOfficerOrder = useCallback(
    (deletedAt: string) => {
      const deletedRecord = (state.deletedOfficerOrders || []).find((d) => d.deletedAt === deletedAt);
      if (!deletedRecord) return { success: false, error: 'Deleted order not found.' };

      const { updatedOrders } = renumberOrdersOnRestore(state.officerOrders, deletedRecord.order);
      const remainingDeleted = state.deletedOfficerOrders.filter((d) => d.deletedAt !== deletedAt);

      persistState({
        ...state,
        officerOrders: updatedOrders,
        deletedOfficerOrders: remainingDeleted,
      });
      return { success: true };
    },
    [state, persistState]
  );

  const recordOfficerPayment = useCallback(
    (orderNumber: number, amount: number) => {
      const order = state.officerOrders.find((o) => o.orderNumber === orderNumber);
      if (!order) return { success: false, error: 'Order not found.' };

      const newPayment: PaymentRecord = {
        id: `pay-${Date.now()}`,
        amount,
        date: formatDate(),
      };

      const updatedPayments = [...(order.payments || []), newPayment];
      const newDue = calculateDue(order.totalAmount, order.discountAmount || 0, order.advance || 0, updatedPayments);

      const updatedOrders = state.officerOrders.map((o) => {
        if (o.orderNumber !== orderNumber) return o;
        return {
          ...o,
          payments: updatedPayments,
          due: newDue,
          updatedAt: new Date().toISOString(),
        };
      });

      persistState({ ...state, officerOrders: updatedOrders });
      return { success: true };
    },
    [state, persistState]
  );

  // --- AIRMAN ORDER ACTIONS ---
  const saveAirmanOrder = useCallback(
    (orderData: any, draftIdToClean?: string) => {
      const missing: string[] = [];
      if (!orderData.customerBdNumber || !orderData.customerBdNumber.trim()) missing.push('BD number');
      if (!orderData.items || orderData.items.length === 0) missing.push('at least one item');

      const missingIv = orderData.items?.some((i: any) => !i.ivNumber || !i.ivNumber.trim());
      if (missingIv) {
        missing.push('an IV-Number on every item');
      }

      if (missing.length > 0) {
        return {
          success: false,
          error: `Please add the ${missing.join(' and ')}.`,
        };
      }

      const normBd = normalizeBdNumber(orderData.customerBdNumber) || orderData.customerBdNumber.trim();

      // IV-number conflict check across other BD numbers
      const ivCheck = validateAirmanIvNumbers(
        orderData.items,
        normBd,
        state.airmanOrders,
        orderData.id
      );

      if (!ivCheck.valid) {
        return {
          success: false,
          error: ivCheck.error || 'IV-Number conflict detected.',
        };
      }

      const existingCust = state.customers.find(
        (c) =>
          c.category === 'Airman' &&
          (normalizeBdNumber(c.bdNumber).toUpperCase() === normBd.toUpperCase() ||
            c.bdNumber.trim().toUpperCase() === normBd.toUpperCase())
      );
      const finalName = existingCust ? existingCust.name : (orderData.customerName || '').trim();

      let updatedOrders = [...state.airmanOrders];
      let savedOrder: AirmanOrder;

      const isEdit =
        typeof orderData.orderNumber === 'number' &&
        orderData.orderNumber > 0 &&
        updatedOrders.some((o) => o.orderNumber === orderData.orderNumber);

      if (isEdit) {
        const index = updatedOrders.findIndex((o) => o.orderNumber === orderData.orderNumber);
        if (index === -1) {
          return { success: false, error: 'Airman order not found for editing.' };
        }
        savedOrder = {
          ...updatedOrders[index],
          ...orderData,
          customerBdNumber: normBd,
          customerName: finalName,
          updatedAt: new Date().toISOString(),
        };
        updatedOrders[index] = savedOrder;
      } else {
        const maxNumber = updatedOrders.reduce((max, o) => Math.max(max, o.orderNumber || 0), 0);
        const nextNumber = maxNumber + 1;

        savedOrder = {
          ...orderData,
          id: `air-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          orderNumber: nextNumber,
          category: 'Airman',
          customerBdNumber: normBd,
          customerName: finalName,
          status: 'Pending',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        updatedOrders = [savedOrder, ...updatedOrders];
      }

      // Sync customer
      const updatedCustomers = syncCustomer(
        'Airman',
        normBd,
        finalName,
        orderData.customerPhone || '',
        state.customers
      );

      const updatedDrafts = draftIdToClean ? state.drafts.filter((d) => d.id !== draftIdToClean) : state.drafts;

      const newState: AppState = {
        ...state,
        airmanOrders: updatedOrders,
        customers: updatedCustomers,
        drafts: updatedDrafts,
      };

      persistState(newState);
      return { success: true, order: savedOrder };
    },
    [state, persistState]
  );

  const updateAirmanOrderStatus = useCallback(
    (orderNumber: number, newStatus: AirmanOrder['status']) => {
      const todayStr = formatDate();
      const updatedOrders = state.airmanOrders.map((o) => {
        if (o.orderNumber !== orderNumber) return o;
        const isNowDelivered = newStatus === 'Delivered';
        return {
          ...o,
          status: newStatus,
          deliveredDate: isNowDelivered ? (o.deliveredDate || todayStr) : undefined,
          receiverName: isNowDelivered ? o.receiverName : undefined,
          receiverPhone: isNowDelivered ? o.receiverPhone : undefined,
          updatedAt: new Date().toISOString(),
        };
      });

      persistState({ ...state, airmanOrders: updatedOrders });
    },
    [state, persistState]
  );

  const confirmAirmanDelivery = useCallback(
    (params: {
      orderNumber: number;
      deliveredDate: string;
      receiverName: string;
      receiverPhone: string;
    }) => {
      const targetOrder = state.airmanOrders.find((o) => o.orderNumber === params.orderNumber);
      if (!targetOrder) return { success: false, error: 'Airman order not found.' };

      const updatedOrders = state.airmanOrders.map((o) => {
        if (o.orderNumber !== params.orderNumber) return o;
        return {
          ...o,
          status: 'Delivered' as OrderStatus,
          deliveredDate: params.deliveredDate,
          receiverName: params.receiverName,
          receiverPhone: params.receiverPhone,
          updatedAt: new Date().toISOString(),
        };
      });

      persistState({ ...state, airmanOrders: updatedOrders });
      return { success: true };
    },
    [state, persistState]
  );

  const deleteAirmanOrder = useCallback(
    (orderNumber: number) => {
      const orderToDelete = state.airmanOrders.find((o) => o.orderNumber === orderNumber);
      if (!orderToDelete) return;

      const deletedRecord: DeletedAirmanOrder = {
        order: orderToDelete,
        deletedAt: new Date().toISOString(),
      };

      const renumbered = renumberOrdersOnDelete(state.airmanOrders, orderNumber);
      persistState({
        ...state,
        airmanOrders: renumbered,
        deletedAirmanOrders: [deletedRecord, ...(state.deletedAirmanOrders || [])],
      });
    },
    [state, persistState]
  );

  const restoreAirmanOrder = useCallback(
    (deletedAt: string) => {
      const deletedRecord = (state.deletedAirmanOrders || []).find((d) => d.deletedAt === deletedAt);
      if (!deletedRecord) return { success: false, error: 'Deleted order not found.' };

      const { updatedOrders } = renumberOrdersOnRestore(state.airmanOrders, deletedRecord.order);
      const remainingDeleted = state.deletedAirmanOrders.filter((d) => d.deletedAt !== deletedAt);

      persistState({
        ...state,
        airmanOrders: updatedOrders,
        deletedAirmanOrders: remainingDeleted,
      });
      return { success: true };
    },
    [state, persistState]
  );

  // --- DRAFT ACTIONS ---
  const saveDraft = useCallback(
    (draftData: any) => {
      const now = new Date().toISOString();
      const draftId = draftData.id || `draft-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      const savedDraft: Draft = {
        ...draftData,
        id: draftId,
        customerBdNumber: normalizeBdNumber(draftData.customerBdNumber) || draftData.customerBdNumber,
        lastSaved: now,
      };

      const existingIndex = state.drafts.findIndex((d) => d.id === draftId);
      let updatedDrafts = [...state.drafts];
      if (existingIndex >= 0) {
        updatedDrafts[existingIndex] = savedDraft;
      } else {
        updatedDrafts = [savedDraft, ...updatedDrafts];
      }

      persistState({ ...state, drafts: updatedDrafts });
      return savedDraft;
    },
    [state, persistState]
  );

  const deleteDraft = useCallback(
    (draftId: string) => {
      const updatedDrafts = state.drafts.filter((d) => d.id !== draftId);
      persistState({ ...state, drafts: updatedDrafts });
    },
    [state, persistState]
  );

  // --- CUSTOMER ACTIONS ---
  const addCustomer = useCallback(
    (data: { category: 'Officer' | 'Airman'; bdNumber: string; name: string; phone: string }) => {
      const normBd = normalizeBdNumber(data.bdNumber) || data.bdNumber.trim();
      const existing = state.customers.find(
        (c) =>
          c.category === data.category &&
          (normalizeBdNumber(c.bdNumber).toUpperCase() === normBd.toUpperCase() ||
            c.bdNumber.trim().toUpperCase() === normBd.toUpperCase())
      );
      if (existing) {
        return {
          success: false,
          error: `This BD number already belongs to ${existing.name}.`,
        };
      }

      const newCustomer: Customer = {
        id: `cust-${Date.now()}`,
        category: data.category,
        bdNumber: normBd,
        name: data.name.trim(),
        phone: data.phone.trim(),
        createdAt: new Date().toISOString(),
      };

      persistState({ ...state, customers: [newCustomer, ...state.customers] });
      return { success: true };
    },
    [state, persistState]
  );

  const updateCustomer = useCallback(
    (bdNumber: string, category: 'Officer' | 'Airman', data: { name: string; phone: string }) => {
      const normBd = normalizeBdNumber(bdNumber) || bdNumber.trim();
      const updatedCustomers = state.customers.map((c) => {
        if (
          c.category === category &&
          (normalizeBdNumber(c.bdNumber).toUpperCase() === normBd.toUpperCase() ||
            c.bdNumber.trim().toUpperCase() === normBd.toUpperCase())
        ) {
          return { ...c, name: data.name.trim(), phone: data.phone.trim() };
        }
        return c;
      });

      // Saving updates name and phone on all that customer's existing orders
      let updatedOfficerOrders = state.officerOrders;
      let updatedAirmanOrders = state.airmanOrders;

      if (category === 'Officer') {
        updatedOfficerOrders = state.officerOrders.map((o) => {
          if (
            normalizeBdNumber(o.customerBdNumber).toUpperCase() === normBd.toUpperCase() ||
            o.customerBdNumber.trim().toUpperCase() === normBd.toUpperCase()
          ) {
            return { ...o, customerName: data.name.trim(), customerPhone: data.phone.trim() };
          }
          return o;
        });
      } else {
        updatedAirmanOrders = state.airmanOrders.map((o) => {
          if (
            normalizeBdNumber(o.customerBdNumber).toUpperCase() === normBd.toUpperCase() ||
            o.customerBdNumber.trim().toUpperCase() === normBd.toUpperCase()
          ) {
            return { ...o, customerName: data.name.trim(), customerPhone: data.phone.trim() };
          }
          return o;
        });
      }

      persistState({
        ...state,
        customers: updatedCustomers,
        officerOrders: updatedOfficerOrders,
        airmanOrders: updatedAirmanOrders,
      });
      return { success: true };
    },
    [state, persistState]
  );

  const deleteCustomer = useCallback(
    (bdNumber: string, category: 'Officer' | 'Airman') => {
      const normBd = normalizeBdNumber(bdNumber) || bdNumber.trim();
      const orderCount =
        category === 'Officer'
          ? state.officerOrders.filter(
              (o) =>
                normalizeBdNumber(o.customerBdNumber).toUpperCase() === normBd.toUpperCase() ||
                o.customerBdNumber.trim().toUpperCase() === normBd.toUpperCase()
            ).length
          : state.airmanOrders.filter(
              (o) =>
                normalizeBdNumber(o.customerBdNumber).toUpperCase() === normBd.toUpperCase() ||
                o.customerBdNumber.trim().toUpperCase() === normBd.toUpperCase()
            ).length;

      if (orderCount > 0) {
        return {
          success: false,
          error: `This customer has ${orderCount} order${orderCount > 1 ? 's' : ''}. Delete those orders first.`,
        };
      }

      const updatedCustomers = state.customers.filter(
        (c) =>
          !(
            c.category === category &&
            (normalizeBdNumber(c.bdNumber).toUpperCase() === normBd.toUpperCase() ||
              c.bdNumber.trim().toUpperCase() === normBd.toUpperCase())
          )
      );

      persistState({ ...state, customers: updatedCustomers });
      return { success: true };
    },
    [state, persistState]
  );

  // --- WORKER ACTIONS ---
  const addWorker = useCallback(
    (name: string, banglaName: string) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Worker name is required.' };

      const existing = state.workers.find((w) => w.name.trim().toLowerCase() === trimmed.toLowerCase());
      if (existing) {
        return { success: false, error: 'This worker already exists.' };
      }

      const maxSerial = state.workers.reduce((max, w) => Math.max(max, w.serialNumber || 0), 0);
      const newWorker: StaffWorker = {
        id: `work-${Date.now()}`,
        serialNumber: maxSerial + 1,
        name: trimmed,
        banglaName: banglaName.trim(),
        active: true,
        createdAt: new Date().toISOString(),
      };

      persistState({ ...state, workers: [...state.workers, newWorker] });
      return { success: true, worker: newWorker };
    },
    [state, persistState]
  );

  const updateWorker = useCallback(
    (id: string, updates: Partial<StaffWorker>) => {
      if (updates.name) {
        const trimmed = updates.name.trim();
        const existing = state.workers.find(
          (w) => w.id !== id && w.name.trim().toLowerCase() === trimmed.toLowerCase()
        );
        if (existing) {
          return { success: false, error: 'This worker already exists.' };
        }
      }

      const updatedWorkers = state.workers.map((w) => (w.id === id ? { ...w, ...updates } : w));
      persistState({ ...state, workers: updatedWorkers });
      return { success: true };
    },
    [state, persistState]
  );

  const deleteWorker = useCallback(
    (id: string) => {
      const hasRows = state.workerRows.some((r) => r.workerId === id && (r.item || r.khoroch));
      const hasPayments = state.workerPayments.some((p) => p.workerId === id);

      if (hasRows || hasPayments) {
        return {
          success: false,
          error: 'This worker has records. Set him inactive instead.',
        };
      }

      const updated = state.workers.filter((w) => w.id !== id);
      persistState({ ...state, workers: updated });
      return { success: true };
    },
    [state, persistState]
  );

  const saveWorkerRows = useCallback(
    (workerId: string, rows: WorkerEntryRow[]) => {
      for (let i = 0; i < rows.length; i++) {
        const r = rows[i];
        const isBlank = !r.item && !r.quantity && !r.khoroch && !r.serial && !r.bdNumber && !r.name;
        if (isBlank) continue;

        if (r.item && (!r.quantity || r.quantity <= 0)) {
          return {
            success: false,
            error: `Row ${i + 1} has an Item but no Quantity. Please specify a quantity above 0.`,
          };
        }
      }

      const validRows = rows
        .filter((r) => {
          const isBlank = !r.item && !r.khoroch;
          return !isBlank;
        })
        .map((r) => ({
          ...r,
          khorochDate: r.khoroch ? r.khorochDate || r.date : r.khorochDate,
          totalTaka: (Number(r.quantity) || 0) * (Number(r.unitPrice) || 0),
        }));

      const otherWorkerRows = state.workerRows.filter((r) => r.workerId !== workerId);
      const updatedRows = [...otherWorkerRows, ...validRows];

      persistState({ ...state, workerRows: updatedRows });
      return { success: true };
    },
    [state, persistState]
  );

  const addWorkerPayment = useCallback(
    (paymentData: Omit<WorkerPayment, 'id' | 'createdAt'>) => {
      const newPayment: WorkerPayment = {
        ...paymentData,
        id: `wpay-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      persistState({ ...state, workerPayments: [newPayment, ...state.workerPayments] });
      return { success: true };
    },
    [state, persistState]
  );

  const updateWorkerPayment = useCallback(
    (id: string, updates: Partial<WorkerPayment>) => {
      const updated = state.workerPayments.map((p) => (p.id === id ? { ...p, ...updates } : p));
      persistState({ ...state, workerPayments: updated });
      return { success: true };
    },
    [state, persistState]
  );

  const deleteWorkerPayment = useCallback(
    (id: string) => {
      const updated = state.workerPayments.filter((p) => p.id !== id);
      persistState({ ...state, workerPayments: updated });
    },
    [state, persistState]
  );

  // --- SETTINGS ACTIONS ---
  const updateSettings = useCallback(
    (newSettings: Partial<ShopSettings>) => {
      persistState({
        ...state,
        settings: {
          ...state.settings,
          ...newSettings,
        },
      });
    },
    [state, persistState]
  );

  const addRunningYear = useCallback(
    (year: string) => {
      const res = validateRunningYear(year);
      if (!res.valid || !res.normalized) {
        return { success: false, error: res.error || 'Invalid year format.' };
      }
      const normalized = res.normalized;
      if (state.settings.runningYears.includes(normalized)) {
        return { success: false, error: 'This running year already exists.' };
      }
      // Insert in sorted order
      const updated = Array.from(new Set([...state.settings.runningYears, normalized])).sort();
      updateSettings({ runningYears: updated });
      return { success: true, normalized };
    },
    [state.settings.runningYears, updateSettings]
  );

  const addOfficerItem = useCallback(
    (name: string, price: number, category = 'Uniform', slipType?: SlipType) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Item name is required.' };
      const exists = state.settings.items.some(
        (i) => i.name.toLowerCase() === trimmed.toLowerCase()
      );
      if (exists) return { success: false, error: 'Item already exists in catalog.' };

      const resolvedSlipType = getItemSlipType(trimmed, slipType);
      const newItem: ItemDefinition = {
        id: `item-${Date.now()}`,
        name: trimmed,
        price: Math.max(0, Number(price) || 0),
        category,
        needsPriceCheck: false,
        slipType: resolvedSlipType,
      };
      updateSettings({ items: [...state.settings.items, newItem] });
      return { success: true };
    },
    [state.settings.items, updateSettings]
  );

  const updateOfficerItem = useCallback(
    (id: string, name: string, price: number, category?: string, slipType?: SlipType) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Item name is required.' };
      const exists = state.settings.items.some(
        (i) => i.id !== id && i.name.toLowerCase() === trimmed.toLowerCase()
      );
      if (exists) return { success: false, error: 'Another item already has this name.' };

      const updated = state.settings.items.map((i) =>
        i.id === id
          ? {
              ...i,
              name: trimmed,
              price: Math.max(0, Number(price) || 0),
              category: category !== undefined ? category : i.category,
              slipType: slipType !== undefined ? slipType : i.slipType || getItemSlipType(trimmed),
              needsPriceCheck: false,
            }
          : i
      );
      updateSettings({ items: updated });
      return { success: true };
    },
    [state.settings.items, updateSettings]
  );

  const deleteOfficerItem = useCallback(
    (id: string) => {
      const updated = state.settings.items.filter((i) => i.id !== id);
      updateSettings({ items: updated });
      return { success: true };
    },
    [state.settings.items, updateSettings]
  );

  const batchUpdateOfficerItems = useCallback(
    (items: ItemDefinition[]) => {
      updateSettings({ items });
      return { success: true };
    },
    [updateSettings]
  );

  const addAirmanItem = useCallback(
    (name: string, slipType?: SlipType) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Item name is required.' };
      const exists = state.settings.airmanItems.some(
        (i) => i.name.toLowerCase() === trimmed.toLowerCase()
      );
      if (exists) return { success: false, error: 'Item already exists in Airman list.' };

      const newItem: AirmanItemDefinition = {
        id: `air-item-${Date.now()}`,
        name: trimmed,
        slipType: getItemSlipType(trimmed, slipType),
      };
      updateSettings({ airmanItems: [...state.settings.airmanItems, newItem] });
      return { success: true };
    },
    [state.settings.airmanItems, updateSettings]
  );

  const updateAirmanItem = useCallback(
    (id: string, name: string, slipType?: SlipType) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Item name is required.' };
      const exists = state.settings.airmanItems.some(
        (i) => i.id !== id && i.name.toLowerCase() === trimmed.toLowerCase()
      );
      if (exists) return { success: false, error: 'Another item already has this name.' };

      const updated = state.settings.airmanItems.map((i) =>
        i.id === id
          ? {
              ...i,
              name: trimmed,
              slipType: slipType !== undefined ? slipType : i.slipType || getItemSlipType(trimmed),
            }
          : i
      );
      updateSettings({ airmanItems: updated });
      return { success: true };
    },
    [state.settings.airmanItems, updateSettings]
  );

  const deleteAirmanItem = useCallback(
    (id: string) => {
      const updated = state.settings.airmanItems.filter((i) => i.id !== id);
      updateSettings({ airmanItems: updated });
      return { success: true };
    },
    [state.settings.airmanItems, updateSettings]
  );

  const addWorkerItem = useCallback(
    (name: string, rate: number) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Item name is required.' };
      const exists = state.settings.workItems.some(
        (wi) => wi.name.toLowerCase() === trimmed.toLowerCase()
      );
      if (exists) return { success: false, error: 'Worker item already exists.' };

      const newItem: WorkItemDefinition = {
        id: `work-item-${Date.now()}`,
        name: trimmed,
        rate: Number(rate) || 0,
      };
      updateSettings({ workItems: [...state.settings.workItems, newItem] });
      return { success: true };
    },
    [state.settings.workItems, updateSettings]
  );

  const updateWorkerItem = useCallback(
    (id: string, name: string, rate: number) => {
      const trimmed = name.trim();
      if (!trimmed) return { success: false, error: 'Item name is required.' };
      const updated = state.settings.workItems.map((wi) =>
        wi.id === id ? { ...wi, name: trimmed, rate: Number(rate) || 0, flaggedCheck: false } : wi
      );
      updateSettings({ workItems: updated });
      return { success: true };
    },
    [state.settings.workItems, updateSettings]
  );

  const deleteWorkerItem = useCallback(
    (id: string) => {
      const updated = state.settings.workItems.filter((wi) => wi.id !== id);
      updateSettings({ workItems: updated });
      return { success: true };
    },
    [state.settings.workItems, updateSettings]
  );

  const restoreFullBackup = useCallback(
    async (backupState: AppState) => {
      try {
        await persistState(backupState);
        return true;
      } catch {
        return false;
      }
    },
    [persistState]
  );

  const contextValue = useMemo(
    () => ({
      state,
      loading,
      error,
      saveOfficerOrder,
      updateOfficerOrderStatus,
      confirmOfficerDelivery,
      deleteOfficerOrder,
      restoreOfficerOrder,
      recordOfficerPayment,
      saveAirmanOrder,
      updateAirmanOrderStatus,
      confirmAirmanDelivery,
      deleteAirmanOrder,
      restoreAirmanOrder,
      saveDraft,
      deleteDraft,
      addCustomer,
      updateCustomer,
      deleteCustomer,
      addWorker,
      updateWorker,
      deleteWorker,
      saveWorkerRows,
      addWorkerPayment,
      updateWorkerPayment,
      deleteWorkerPayment,
      updateSettings,
      addRunningYear,
      addOfficerItem,
      updateOfficerItem,
      deleteOfficerItem,
      batchUpdateOfficerItems,
      addAirmanItem,
      updateAirmanItem,
      deleteAirmanItem,
      addWorkerItem,
      updateWorkerItem,
      deleteWorkerItem,
      restoreFullBackup,
      refreshData,
      resetToFreshState,
    }),
    [
      state,
      loading,
      error,
      saveOfficerOrder,
      updateOfficerOrderStatus,
      confirmOfficerDelivery,
      deleteOfficerOrder,
      restoreOfficerOrder,
      recordOfficerPayment,
      saveAirmanOrder,
      updateAirmanOrderStatus,
      confirmAirmanDelivery,
      deleteAirmanOrder,
      restoreAirmanOrder,
      saveDraft,
      deleteDraft,
      addCustomer,
      updateCustomer,
      deleteCustomer,
      addWorker,
      updateWorker,
      deleteWorker,
      saveWorkerRows,
      addWorkerPayment,
      updateWorkerPayment,
      deleteWorkerPayment,
      updateSettings,
      addRunningYear,
      addOfficerItem,
      updateOfficerItem,
      deleteOfficerItem,
      batchUpdateOfficerItems,
      addAirmanItem,
      updateAirmanItem,
      deleteAirmanItem,
      addWorkerItem,
      updateWorkerItem,
      deleteWorkerItem,
      restoreFullBackup,
      refreshData,
      resetToFreshState,
    ]
  );

  return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
